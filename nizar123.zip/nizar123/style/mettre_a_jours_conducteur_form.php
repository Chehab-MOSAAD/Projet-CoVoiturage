<!DOCTYPE html>
<html lang="fr">
<head>
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="Site keywords here">
    <meta name="description" content="">
    <meta name='copyright' content=''>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- Title -->
    <title>Mise à jour des informations utilisateur</title>
    
    <!-- Favicon -->
    <link rel="icon" href="images/favicon.png">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Nice Select CSS -->
    <link rel="stylesheet" href="css/nice-select.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!-- icofont CSS -->
    <link rel="stylesheet" href="css/icofont.css">
    <!-- Slicknav -->
    <link rel="stylesheet" href="css/slicknav.min.css">
    <!-- Owl Carousel CSS -->
    <link rel="stylesheet" href="css/owl-carousel.css">
    <!-- Datepicker CSS -->
    <link rel="stylesheet" href="css/datepicker.css">
    <!-- Animate CSS -->
    <link rel="stylesheet" href="css/animate.min.css">
    <!-- Magnific Popup CSS -->
    <link rel="stylesheet" href="css/magnific-popup.css">
    
    <!-- Medipro CSS -->
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <style>
        input, select, button {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }
        input:focus, select:focus, button:focus {
            border-color: #1c87c9;
            outline: none;
            box-shadow: 0 0 5px rgba(28, 135, 201, 0.5);
        }
        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 18px;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #45a049;
        }
        fieldset {
            border: none;
            margin: 15px 0;
        }
        legend {
            font-size: 18px;
            margin-bottom: 10px;
            color: #1c87c9;
        }
        .radio-group, .date-group {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        .radio-group label, .date-group label {
            display: flex;
            align-items: center;
            font-weight: 500;
            margin-right: 10px;
        }
        .radio-group input, .date-group select {
            margin-right: 5px;
            accent-color: #4CAF50;
        }
        .date-group select {
            width: 32%;
        }
    </style>
</head>
    <body>
	
		<!-- Preloader -->
        <div class="preloader">
            <div class="loader">
                <div class="loader-outter"></div>
                <div class="loader-inner"></div>

                <div class="indicator"> 
                    <svg width="16px" height="12px">
                        <polyline id="back" points="1 6 4 6 6 11 10 1 12 6 15 6"></polyline>
                        <polyline id="front" points="1 6 4 6 6 11 10 1 12 6 15 6"></polyline>
                    </svg>
                </div>
            </div>
        </div>
        <!-- End Preloader -->
	
		<!-- Header Area -->
		<header class="header" >
			<!-- Header Inner -->
			<div class="header-inner">
				<div class="container">
					<div class="inner">
						<div class="row">
							<div class="col-lg-3 col-md-3 col-12">
								<!-- Start Logo -->
								<div class="logo">
									<a href="/../CovoiTECH/chehab/Utilisateur_index.html"><img src="images/logo.png" alt="#"></a>
								</div>
								<!-- End Logo -->
								<!-- Mobile Nav -->
								<div class="mobile-nav"></div>
								<!-- End Mobile Nav -->
							</div>
							<div class="col-lg-7 col-md-9 col-12">
								<!-- Main Menu -->
								<div class="main-menu">
									<nav class="navigation">
										<ul class="nav menu">
											<li><a href="/../CovoiTECH/chehab/Utilisateur_index.html">Accueil</a></li>
											<li><a href="/../CovoiTECH/Miniar/recherche_voyage.php">Recherche</a></li>
											<li><a href="history.php">Profil</a></li>
											<li><a href="" class="typewrite" data-period="2000" data-type='[ "Bienvenue chez CovoiTECH", "Votre trajet, notre priorité", "Ensemble sur la route !" ]'></a></li>
										</ul>
									</nav>
								</div>
								<!--/ End Main Menu -->
							</div>
							<div class="col-lg-1 col-12">
								<div class="get-quote">
									<a href="deconnexion.php" class="btn">Déonnexion</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--/ End Header Inner -->
		</header>
        <!-- end section -->
        <br/>
        <h3 style="text-align: center;">Mettre à jour les informations du conducteur</h3>
        <br/>

        <div class="container">
            <?php if (!empty($message)): ?>
                <p><?php echo $message; ?></p>
            <?php endif; ?>

            <form method="POST" action="mettre_a_jours_conducteur.php">
                <input type="hidden" name="id_utilisateur" value="<?php echo htmlspecialchars($driverInfo['idutilisateur'] ?? ''); ?>">
                <label for="numPermis">Numéro de Permis:</label>
                <input type="text" id="numPermis" name="numPermis" value="<?php echo htmlspecialchars($driverInfo['numpermis'] ?? ''); ?>" required><br>
                <label for="points">Points:</label>
                <input type="number" id="points" name="points" value="<?php echo htmlspecialchars($driverInfo['points'] ?? ''); ?>" required><br>
                <label for="noteConducteur">Note du Conducteur:</label>
                <input type="number" step="0.1" id="noteConducteur" name="noteConducteur" value="<?php echo htmlspecialchars($driverInfo['noteconducteur'] ?? ''); ?>" required><br>
                <label for="matricule">Matricule:</label>
                <input type="text" id="matricule" name="matricule" value="<?php echo htmlspecialchars($driverInfo['matricule'] ?? ''); ?>" required><br>
                <label for="marque">Marque:</label>
                <input type="text" id="marque" name="marque" value="<?php echo htmlspecialchars($driverInfo['marque'] ?? ''); ?>" required><br>
                <label for="modele">Modèle:</label>
                <input type="text" id="modele" name="modele" value="<?php echo htmlspecialchars($driverInfo['modele'] ?? ''); ?>" required><br>
                <label for="type">Type:</label>
                <select id="type" name="type" required>
                    <option value="SUV" <?php if (($driverInfo['type'] ?? '') === 'SUV') echo 'selected'; ?>>SUV</option>
                    <option value="Berline" <?php if (($driverInfo['type'] ?? '') === 'Berline') echo 'selected'; ?>>Berline</option>
                    <option value="Compacte" <?php if (($driverInfo['type'] ?? '') === 'Compacte') echo 'selected'; ?>>Compacte</option>
                    <option value="Monospace" <?php if (($driverInfo['type'] ?? '') === 'Monospace') echo 'selected'; ?>>Monospace</option>
                </select><br>
                <label for="couleur">Couleur:</label>
                <select id="couleur" name="couleur" required>
                    <option value="bleu" <?php if (($driverInfo['couleur'] ?? '') === 'bleu') echo 'selected'; ?>>Bleu</option>
                    <option value="violet" <?php if (($driverInfo['couleur'] ?? '') === 'violet') echo 'selected'; ?>>Violet</option>
                    <option value="rose" <?php if (($driverInfo['couleur'] ?? '') === 'rose') echo 'selected'; ?>>Rose</option>
                    <option value="rouge" <?php if (($driverInfo['couleur'] ?? '') === 'rouge') echo 'selected'; ?>>Rouge</option>
                    <option value="orange" <?php if (($driverInfo['couleur'] ?? '') === 'orange') echo 'selected'; ?>>Orange</option>
                    <option value="jaune" <?php if (($driverInfo['couleur'] ?? '') === 'jaune') echo 'selected'; ?>>Jaune</option>
                    <option value="vert" <?php if (($driverInfo['couleur'] ?? '') === 'vert') echo 'selected'; ?>>Vert</option>
                    <option value="noir" <?php if (($driverInfo['couleur'] ?? '') === 'noir') echo 'selected'; ?>>Noir</option>
                    <option value="marron" <?php if (($driverInfo['couleur'] ?? '') === 'marron') echo 'selected'; ?>>Marron</option>
                    <option value="gris" <?php if (($driverInfo['couleur'] ?? '') === 'gris') echo 'selected'; ?>>Gris</option>
                    <option value="aluminium" <?php if (($driverInfo['couleur'] ?? '') === 'aluminium') echo 'selected'; ?>>Aluminium</option>
                    <option value="argent" <?php if (($driverInfo['couleur'] ?? '') === 'argent') echo 'selected'; ?>>Argent</option>
                    <option value="blanc" <?php if (($driverInfo['couleur'] ?? '') === 'blanc') echo 'selected'; ?>>Blanc</option>
                </select><br>
                <button type="submit" name="mettre_a_jours">Mettre à jour</button>
            </form>
            <form action="success.php" method="post">
                <button type="submit" class="back-button">Retour</button>
            </form>
        </div>

		<!-- Footer Area -->
		<footer id="footer" class="footer ">
			<div class="footer-top">
				<div class="container">
					<div class="row">
						<div class="col-lg-9 col-md-6 col-12">
							<div class="single-footer">
								<h2>À propos</h2>
								<p>Notre site simule une plateforme intuitive où les utilisateurs peuvent proposer ou rechercher des trajets, gérer leurs réservations et interagir avec d’autres membres. L’accent a été mis sur la simplicité d’utilisation, la sécurité des données et la  Création d’une expérience utilisateur engageante. </p>
								<p><br>Ce site web de covoiturage est le fruit d’un projet académique mené par un groupe d'étudiants de l’UPSSITECH, développé en PHP, HTML, CSS, Javascript et appuyé par une base de données robuste. Il sert principalement de démonstration des compétences techniques acquises durant notre année universitaire et n’est pas destiné à un usage commercial.</p>
							</div>
						</div>
						<div class="col-lg-3 col-md-6 col-12">
							<div class="single-footer f-link">
								<h2>Membres de l’équipe</h2>
								<p>-> Chehab MOSAAD
									<br>-> Nizar SLAMA SEFI
									<br>-> Miniar JABRI
									<br>-> Lina AHNOUDJ 
									<br>-> Linda BEDOUI
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
		<!--/ End Footer Area -->
		
		<!-- jquery Min JS -->
        <script src="js/jquery.min.js"></script>
		<!-- jquery Migrate JS -->
		<script src="js/jquery-migrate-3.0.0.js"></script>
		<!-- jquery Ui JS -->
		<script src="js/jquery-ui.min.js"></script>
		<!-- Easing JS -->
        <script src="js/easing.js"></script>
		<!-- Color JS -->
		<script src="js/colors.js"></script>
		<!-- Popper JS -->
		<script src="js/popper.min.js"></script>
		<!-- Bootstrap Datepicker JS -->
		<script src="js/bootstrap-datepicker.js"></script>
		<!-- Jquery Nav JS -->
        <script src="js/jquery.nav.js"></script>
		<!-- Slicknav JS -->
		<script src="js/slicknav.min.js"></script>
		<!-- ScrollUp JS -->
        <script src="js/jquery.scrollUp.min.js"></script>
		<!-- Niceselect JS -->
		<script src="js/niceselect.js"></script>
		<!-- Tilt Jquery JS -->
		<script src="js/tilt.jquery.min.js"></script>
		<!-- Owl Carousel JS -->
        <script src="js/owl-carousel.js"></script>
		<!-- counterup JS -->
		<script src="js/jquery.counterup.min.js"></script>
		<!-- Steller JS -->
		<script src="js/steller.js"></script>
		<!-- Wow JS -->
		<script src="js/wow.min.js"></script>
		<!-- Magnific Popup JS -->
		<script src="js/jquery.magnific-popup.min.js"></script>
		<!-- Counter Up CDN JS -->
		<script src="http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>
		<!-- Bootstrap JS -->
		<script src="js/bootstrap.min.js"></script>
		<!-- Main JS -->
		<script src="js/main.js"></script>
    </body>
</html>