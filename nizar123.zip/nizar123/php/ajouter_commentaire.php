<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['driver_info'])) {
    header("Location: connexion_conducteur.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['idTrajet']) && isset($_POST['commentaire'])) {
    $idTrajet = $_POST['idTrajet'];
    $commentaire = $_POST['commentaire'];

    $query = "UPDATE Trajet SET CommentaireTrajetConducteur = $1 WHERE IdTrajet = $2";
    $result = pg_query_params($db, $query, array($commentaire, $idTrajet));

    if ($result) {
        $_SESSION['message'] = 'Commentaire ajouté avec succès.';
    } else {
        $_SESSION['message'] = 'Erreur lors de l ajout du commentaire.';
    }
    header("Location: historique_conducteur.php");
    exit;
}
?>
