<?php
// ajouter_conducteur.php: Handles the registration of a new driver

// Start the session to manage user authentication and other session data
session_start();

// Include the database connection file
require 'db.php'; // Ensure your database connection parameters are correct in this file

// Initialize the message
$message = '';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    die("Vous devez être connecté pour voir cette page.");
}

// Retrieve user ID from session
$userId = $_SESSION['user_id'];
$adminId = 3; // ID de l'administrateur à qui le message sera envoyé

// Check if the admin exists
$query = "SELECT COUNT(*) FROM Administrateur WHERE IdAdm = $1";
$result = pg_query_params($db, $query, [$adminId]);
if (!$result || pg_fetch_result($result, 0, 0) == 0) {
    die("L'administrateur avec l'ID $adminId n'existe pas.");
}

// Get the current date
$currentDay = date('j');
$currentMonth = date('n');
$currentYear = date('Y');

// Check if the date exists in LaDate
$query = "SELECT COUNT(*) FROM LaDate WHERE Jour = $1 AND Mois = $2 AND Annee = $3";
$result = pg_query_params($db, $query, [$currentDay, $currentMonth, $currentYear]);
if (!$result || pg_fetch_result($result, 0, 0) == 0) {
    // Insert the date into LaDate if it doesn't exist
    $query = "INSERT INTO LaDate (Jour, Mois, Annee) VALUES ($1, $2, $3)";
    $result = pg_query_params($db, $query, [$currentDay, $currentMonth, $currentYear]);
    if (!$result) {
        die("Erreur lors de l'insertion de la date dans LaDate: " . pg_last_error($db));
    }
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['ajouter_conducteur'])) {
    // Retrieve and sanitize data from the POST request
    $numPermis = filter_var($_POST['numPermis'], FILTER_SANITIZE_STRING);
    $matricule = filter_var($_POST['matricule'], FILTER_SANITIZE_STRING);
    $marque = filter_var($_POST['marque'], FILTER_SANITIZE_STRING);
    $modele = filter_var($_POST['modele'], FILTER_SANITIZE_STRING);
    $type = filter_var($_POST['type'], FILTER_SANITIZE_STRING);
    $couleur = filter_var($_POST['couleur'], FILTER_SANITIZE_STRING);
    $nbrPlace = (int)$_POST['nbrPlace'];
    $carburant = filter_var($_POST['carburant'], FILTER_SANITIZE_STRING);

    // Validate the data
    if (strlen($numPermis) == 0 || !preg_match('/^[A-Za-z0-9]+$/', $numPermis)) {
        $message = "Numéro de permis invalide.";
    } elseif (strlen($matricule) == 0 || !preg_match('/^[A-Za-z0-9]+$/', $matricule)) {
        $message = "Matricule invalide.";
    } elseif (!preg_match('/^[A-Za-z0-9 ]+$/', $marque)) {
        $message = "Marque invalide.";
    } elseif (!preg_match('/^[A-Za-z0-9 ]+$/', $modele)) {
        $message = "Modèle invalide.";
    } elseif (!in_array($type, ['SUV', 'Berline', 'Compacte', 'Monospace'])) {
        $message = "Type de véhicule invalide.";
    } elseif (!in_array($couleur, ['bleu', 'violet', 'rose', 'rouge', 'orange', 'jaune', 'vert', 'noir', 'marron', 'gris', 'aluminium', 'argent', 'blanc'])) {
        $message = "Couleur de véhicule invalide.";
    } elseif ($nbrPlace <= 0 || $nbrPlace > 100) {
        $message = "Nombre de places invalide.";
    } elseif (!in_array($carburant, ['essence', 'diesel', 'éthanol', 'gaz', 'électrique', 'hybride'])) {
        $message = "Type de carburant invalide.";
    } else {
        // Start a transaction
        pg_query($db, "BEGIN");


        try {
            // Prepare the message to be sent to the admin
            $messageContent = "Nouvelle demande d'inscription de conducteur :
                Numéro de permis : $numPermis
                Matricule : $matricule
                Marque : $marque
                Modèle : $modele
                Type : $type
                Couleur : $couleur
                Nombre de places : $nbrPlace
                Carburant : $carburant
                Utilisateur ID : $userId";

            // Insert the message into Messagerie
            $query = "INSERT INTO Messagerie (Message) VALUES ($1) RETURNING IdSession";
            $params = [$messageContent];
            $result = pg_query_params($db, $query, $params);

            if (!$result) {
                throw new Exception("Erreur lors de l'envoi du message: " . pg_last_error($db));
            }

            // Get the IdSession of the inserted message
            $idSession = pg_fetch_result($result, 0, 'idsession');

            // Insert the message into the Envoyer table
            $query = "INSERT INTO Envoyer (IdSession, IdUtilisateur, Jour, Mois, Annee) VALUES ($1, $2, $3, $4, $5)";
            $params = [$idSession, $userId, $currentDay, $currentMonth, $currentYear];
            $result = pg_query_params($db, $query, $params);

            if (!$result) {
                throw new Exception("Erreur lors de l'envoi du message: " . pg_last_error($db));
            }

            // Insert the message into the RecevoirAdmin table for the admin
            $query = "INSERT INTO RecevoirAdmin (IdSession, IdAdm, Jour, Mois, Annee) VALUES ($1, $2, $3, $4, $5)";
            $params = [$idSession, $adminId, $currentDay, $currentMonth, $currentYear];
            $result = pg_query_params($db, $query, $params);

            if (!$result) {
                throw new Exception("Erreur lors de l'envoi du message: " . pg_last_error($db));
            }

            // Commit the transaction
            pg_query($db, "COMMIT");

            // Display success message and redirect after 3 seconds
            echo "<html><head><meta http-equiv='refresh' content='3;url=/../CovoiTECH/chehab/Utilisateur_index.html'></head><body>";
            echo "<h2>Inscription réussie ! Vous serez redirigé dans 3 secondes...</h2>";
            echo "</body></html>";
            exit;

        } catch (Exception $e) {
            // Rollback the transaction in case of error
            pg_query($db, "ROLLBACK");
            $message = $e->getMessage();
        }
    }
}

// Inclure le formulaire d'inscription
include "../style/ajouter_conducteur_form.php";
?>
