<?php
$host = 'localhost';
$dbname = 'BD_CovoiTECH';
$user = 'postgres';
$password = '13102002';
$port = "5432";
$connectionString = "host=$host dbname=$dbname user=$user password=$password";


// Essayer de se connecter à la base de données
$db = pg_connect($connectionString);

if ($db) {
    echo "";
} else {
    die("Erreur de connexion : " . pg_last_error());
}
?>
