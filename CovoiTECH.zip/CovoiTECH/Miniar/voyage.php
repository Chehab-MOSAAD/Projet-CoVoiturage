<!doctype html>
<html class="no-js" lang="zxx">
    <head>
        <!-- Meta Tags -->
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="keywords" content="Site keywords here">
		<meta name="description" content="">
		<meta name='copyright' content=''>
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
        <title>Details de trajets</title>
        <!-- CSS FILES -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

		<!-- Favicon -->
        <link rel="icon" href="images/favicon.png">
		
		<!-- Google Fonts -->
		<link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<!-- Nice Select CSS -->
		<link rel="stylesheet" href="css/nice-select.css">
		<!-- Font Awesome CSS -->
        <link rel="stylesheet" href="css/font-awesome.min.css">
		<!-- icofont CSS -->
        <link rel="stylesheet" href="css/icofont.css">
		<!-- Slicknav -->
		<link rel="stylesheet" href="css/slicknav.min.css">
		<!-- Owl Carousel CSS -->
        <link rel="stylesheet" href="css/owl-carousel.css">
		<!-- Datepicker CSS -->
		<link rel="stylesheet" href="css/datepicker.css">
		<!-- Animate CSS -->
        <link rel="stylesheet" href="css/animate.min.css">
		<!-- Magnific Popup CSS -->
        <link rel="stylesheet" href="css/magnific-popup.css">
		
		<!-- Medipro CSS -->
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="css/responsive.css">

    <style>
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .row {
            margin-top: 20px;
            display: flex;
            flex-wrap: wrap;
            align-items: stretch;
        }

        .col-md-4 {
            display: flex;
            flex-direction: column;
            flex: 0 0 33.333333%; /* Change based on your layout */
            max-width: 33.333333%; /* Change based on your layout */
            padding: 0 15px;
        }

        .info-section {
            background-color: #f8f9fa;
            border: 8px solid #3BB143;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 20px;
            display: flex;
            flex-direction: column;
            flex-grow: 1; /* Ensures that the card stretches to fill the container */
        }

        .info-section h2 {
            margin-top: 0;
            margin-bottom: 10px;
        }

        .info-section p {
            margin-bottom: 5px;
            flex-grow: 1; /* Allows the paragraph to fill the space and push buttons down */
        }

        .card {
        display: flex;
        flex-direction: column; /* Organise le contenu de la carte en colonne */
        }
        .btnm-container {
            width: 100%; /* Assure que le conteneur du bouton s'étend sur toute la largeur */
            order: -1; /* Place le conteneur du bouton en haut de la carte */
        }

        .btnm, .btnm-primary {
            width: 100%; /* Assure que le bouton s'étend sur toute la largeur de la carte */
            margin-top: 10px; /* Ajoute de l'espace au-dessus du bouton */
            background-color: #3BB143; /* Définit la couleur du bouton */
            margin-bottom: 10px; /* Ajoute de l'espace en dessous du bouton */
            padding-top: 10px; /* Ajoute de l'espace à l'intérieur du bouton (en haut) */
            padding-bottom: 10px; /* Ajoute de l'espace à l'intérieur du bouton (en bas) */
        }

    </style>
</head>

<body>
    <?php
        include 'reservation.php';
    ?>
    <!-- Preloader -->
    <div class="preloader">
        <div class="loader">
            <div class="loader-outter"></div>
            <div class="loader-inner"></div>

            <div class="indicator"> 
                <svg width="16px" height="12px">
                    <polyline id="back" points="1 6 4 6 6 11 10 1 12 6 15 6"></polyline>
                    <polyline id="front" points="1 6 4 6 6 11 10 1 12 6 15 6"></polyline>
                </svg>
            </div>
        </div>
    </div>
    <!-- End Preloader -->

    <!-- Header Area -->
    <header class="header" >
        <!-- Header Inner -->
        <div class="header-inner">
            <div class="container">
                <div class="inner">
                    <div class="row">
                        <div class="col-lg-3 col-md-3 col-12">
                            <!-- Start Logo -->
                            <div class="logo">
                                <a href="..\chehab\Utilisateur_index.html"><img src="images/logo.png" alt="#"></a>
                            </div>
                            <!-- End Logo -->
                            <!-- Mobile Nav -->
                            <div class="mobile-nav"></div>
                            <!-- End Mobile Nav -->
                        </div>
                        <div class="col-lg-7 col-md-9 col-12">
                            <!-- Main Menu -->
                            <div class="main-menu">
                                <nav class="navigation">
                                    <ul class="nav menu">
                                        <li><a href="..\chehab\Utilisateur_index.html">Accueil</a></li>
                                        <li><a href="recherche_voyage.php">Recherche</a></li>
                                        <li><a href="..\nizar\php\history.php">Profil</a></li>
                                        <li><a href="" class="typewrite" data-period="2000" data-type='[ "Bienvenue chez CovoiTECH", "Votre trajet, notre priorité", "Ensemble sur la route !" ]'></a></li>
                                    </ul>
                                </nav>
                            </div>
                            <!--/ End Main Menu -->
                        </div>
                        <div class="col-lg-1 col-12">
                            <div class="get-quote">
                                <a href="..\nizar\php\deconnexion.php" class="btn">Déonnexion</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/ End Header Inner -->
    </header>
    <!-- end section -->

    <div class="container mt-4">
        <!-- Notification Bar -->
        <div class="row">
            <div class="col text-center">
              <p><strong>Attention : Votre réservation sera confirmée lorsque le conducteur acceptera votre demande !</strong></p>
            </div>
        </div>
    </div>  
    <div class="container mt-4">
        <!-- Voiture, Conducteur et Trajet en trois colonnes -->
        <div class="row">
       <!-- Voiture Section -->

    <div class="col-md-4">
        <div class="info-section car-info">
            <h3>Voiture:</h3>
            <p><strong>Marque:</strong> <?php echo htmlspecialchars($Trajet['marque']); ?></p>
            <p><strong>Modèle:</strong> <?php echo htmlspecialchars($Trajet['modele']); ?></p>
            <p><strong>Couleur:</strong> <?php echo htmlspecialchars($Trajet['couleur']); ?></p>
            <p><strong>Nombre de Places:</strong> <?php echo htmlspecialchars($Trajet['nbrplace']); ?></p>
            <p><strong>Type de la voiture:</strong> <?php echo htmlspecialchars($Trajet['type']); ?></p>
            <p><strong>Le carburant:</strong> <?php echo htmlspecialchars($Trajet['carburant']); ?></p>
        </div>
    </div>   
    
    <!-- Trajet Section -->
    <div class="col-md-4">
        <div class="info-section ">
            <h3>Trajet:</h3>
            <p><strong>Départ:</strong> <?php echo htmlspecialchars($Trajet['nomruedepart'] . ' ' . $Trajet['numruedepart'] . ', ' . $Trajet['codepostaldepart'] . ' ' . $Trajet['villedepart']); ?></p>
            <p><strong>Arrivée:</strong> <?php echo htmlspecialchars($Trajet['nomruearrivee'] . ' ' . $Trajet['numruearrivee'] . ', ' . $Trajet['codepostalarrivee'] . ' ' . $Trajet['villearrivee']); ?></p>
            <p><strong>Commentaire:</strong> <?php echo htmlspecialchars($Trajet['commentairetrajetconducteur']); ?></p>
            <p><strong>Places Disponibles:</strong> <?php echo htmlspecialchars($Trajet['placedispo']); ?></p>
            <p><strong>Heure De Départ :</strong> <?php echo htmlspecialchars($Trajet['heuredepart']); ?></p>
            <p><strong>Heure D'arrivée:</strong> <?php echo htmlspecialchars($Trajet['heurearrivee']); ?></p>
        </div>
    </div>

    <!-- Conducteur Section -->
    <div class="col-md-4">
        <div class="info-section driver-info">
            <h3>Conducteur:</h3>
            <p><strong>Nom:</strong> <?php echo htmlspecialchars($Trajet['nom']); ?></p>
            <p><strong>Prénom:</strong> <?php echo htmlspecialchars($Trajet['prenom']); ?></p>
            <p><strong>Date de naissance:</strong> <?php echo htmlspecialchars($Trajet['jour']) . "/" . htmlspecialchars($Trajet['mois']) . "/" . htmlspecialchars($Trajet['annee']); ?></p>
            <p><strong>Sexe:</strong> <?php echo htmlspecialchars($Trajet['sexe']); ?></p>
            <p><strong>Handicap:</strong> <?php echo $Trajet['handicap'] ? 'Oui' : 'Non'; ?></p>
            <p><strong>Langue Parlée:</strong> <?php echo htmlspecialchars($Trajet['langueparle1']); ?></p>
            <p><strong>Langue parlée:</strong> <?php echo htmlspecialchars($Trajet['langueparle2']); ?></p>
            <p><strong>Fumeur:</strong> <?php echo $Trajet['fumeur'] ? 'Oui' : 'Non'; ?></p>
            <p><strong>Note:</strong> <?php echo htmlspecialchars($Trajet['noteconducteur']); ?></p>
            <!-- Add more driver details here -->
        </div>
    </div>
    
    <div class="col-md-4">

    <div class="escale-info">
     <!-- Section Escales -->
            <div class="info-section escales-info">
                <h3>Escales:</h3>   
                <?php
       if (!empty($escales)) {
        foreach ($escales as $escale) {
            ?>
            <p><strong>Lieu:</strong> <?php echo htmlspecialchars($escale['lieu']); ?></p>
            <p><strong>Nom de la Rue:</strong> <?php echo htmlspecialchars($escale['nomrue']); ?></p>
            <p><strong>Numéro de Rue:</strong> <?php echo htmlspecialchars($escale['numrue']); ?></p>
            <p><strong>Code Postal:</strong> <?php echo htmlspecialchars($escale['codepostal']); ?></p>
            <p><strong>Accessibilité:</strong> <?php echo $escale['accessibilite'] ? 'Oui' : 'Non'; ?></p>
            <?php
        }
       } else {
        echo "<p>Aucune escale pour ce trajet.</p>";
       }
        ?>            
    </div>
    </div>
    </div>
    <div class="col-md-4">
           <!-- Bouton Réserver -->             
             <form a method="post" class="btnm-container">
                   <button type="submit" name="submit" class="btnm btnm-primary">Réserver ce voyage</button>
             </form>   
    </div>
    <div class="col-md-4">
        <!-- bouton pour envoyer un message à ce conducteur-->
        <form class="btn-container" onsubmit="event.preventDefault(); window.location.href='/../CovoiTECH/Linda/envoyer_message.php';">
            <button type="submit" class="btnm btnm-primary btn-block">Contacter Le conducteur</button>
        </form>
    </div>
    
    <script>
        function contactDriver(driverPermisNumber) {
            // Implement the logic to contact the driver
            alert("Contacting driver with permit number: " + driverPermisNumber);
        }

        function requestReservation(tripId) {
            // Implement the logic for a reservation request
            alert("Requesting reservation for trip ID: " + tripId);
        }
        
    </script>

		<!-- Footer Area -->
		<footer id="footer" class="footer ">
			<div class="footer-top">
				<div class="container">
					<div class="row">
						<div class="col-lg-9 col-md-6 col-12">
							<div class="single-footer">
								<h2>À propos</h2>
								<p>Notre site simule une plateforme intuitive où les utilisateurs peuvent proposer ou rechercher des trajets, gérer leurs réservations et interagir avec d’autres membres. L’accent a été mis sur la simplicité d’utilisation, la sécurité des données et la  Création d’une expérience utilisateur engageante. </p>
								<p><br>Ce site web de covoiturage est le fruit d’un projet académique mené par un groupe d'étudiants de l’UPSSITECH, développé en PHP, HTML, CSS, Javascript et appuyé par une base de données robuste. Il sert principalement de démonstration des compétences techniques acquises durant notre année universitaire et n’est pas destiné à un usage commercial.</p>
							</div>
						</div>
						<div class="col-lg-3 col-md-6 col-12">
							<div class="single-footer f-link">
								<h2>Membres de l’équipe</h2>
								<p>-> Chehab MOSAAD
									<br>-> Nizar SLAMA SEFI
									<br>-> Miniar JABRI
									<br>-> Lina AHNOUDJ 
									<br>-> Linda BEDOUI
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
		<!--/ End Footer Area -->
		
		<!-- jquery Min JS -->
        <script src="js/jquery.min.js"></script>
		<!-- jquery Migrate JS -->
		<script src="js/jquery-migrate-3.0.0.js"></script>
		<!-- jquery Ui JS -->
		<script src="js/jquery-ui.min.js"></script>
		<!-- Easing JS -->
        <script src="js/easing.js"></script>
		<!-- Color JS -->
		<script src="js/colors.js"></script>
		<!-- Popper JS -->
		<script src="js/popper.min.js"></script>
		<!-- Bootstrap Datepicker JS -->
		<script src="js/bootstrap-datepicker.js"></script>
		<!-- Jquery Nav JS -->
        <script src="js/jquery.nav.js"></script>
		<!-- Slicknav JS -->
		<script src="js/slicknav.min.js"></script>
		<!-- ScrollUp JS -->
        <script src="js/jquery.scrollUp.min.js"></script>
		<!-- Niceselect JS -->
		<script src="js/niceselect.js"></script>
		<!-- Tilt Jquery JS -->
		<script src="js/tilt.jquery.min.js"></script>
		<!-- Owl Carousel JS -->
        <script src="js/owl-carousel.js"></script>
		<!-- counterup JS -->
		<script src="js/jquery.counterup.min.js"></script>
		<!-- Steller JS -->
		<script src="js/steller.js"></script>
		<!-- Wow JS -->
		<script src="js/wow.min.js"></script>
		<!-- Magnific Popup JS -->
		<script src="js/jquery.magnific-popup.min.js"></script>
		<!-- Counter Up CDN JS -->
		<script src="http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>
		<!-- Bootstrap JS -->
		<script src="js/bootstrap.min.js"></script>
		<!-- Main JS -->
		<script src="js/main.js"></script>
    </body>
</html>
