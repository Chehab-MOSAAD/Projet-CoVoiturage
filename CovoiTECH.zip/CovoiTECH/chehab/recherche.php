<?php
session_start();
include 'classes\Database.php';

function clean_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get input data from the form
    $VilleDepart = clean_input($_POST['VilleDepart']);
    $VilleArrivee = clean_input($_POST['VilleArrivee']);
    $departureDate = clean_input($_POST['departureDate']);
    $PlaceDispo = clean_input($_POST['PlaceDispo']);
    // Define departureYear based on the provided departureDate
    $departureYear = date('Y', strtotime($departureDate));

    // Connect to the database
    $pdo = new PDO('pgsql:host=localhost;dbname=BD_CovoiTECH', 'postgres', '13102002');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Prepare the SQL statement
    $stmt = $pdo->prepare('SELECT T.* 
                           FROM "Trajet" T
                           LEFT JOIN "Contient" C1 ON T."IdTrajet" = C1."IdTrajet"
                           LEFT JOIN "Escale" E1 ON C1."IdEscale" = E1."IdEscale"
                           WHERE (T."VilleDepart" = :VilleDepart 
                                  AND T."VilleArrivee" = :VilleArrivee 
                                  AND T."PlaceDispo" >= :PlaceDispo)
                                 OR (E1."Lieu" = :VilleDepart 
                                  AND T."VilleArrivee" = :VilleArrivee 
                                  AND T."PlaceDispo" >= :PlaceDispo)');

    // Bind parameters
    $stmt->bindParam(':VilleDepart', $VilleDepart);
    $stmt->bindParam(':VilleArrivee', $VilleArrivee);
    $stmt->bindParam(':PlaceDispo', $PlaceDispo);

    // Execute the query
    $stmt->execute();

    // Fetch results
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch the results
    $trajets = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Check if any results are returned
    if (empty($trajets)) {
        echo "<p>Aucun trajet disponible pour ce parcours.</p>";
    }else {
    $validTrips = [];
    foreach ($trajets as $t) {
        $id = $t['idtrajet'];

        // Préparez la requête pour récupérer le jour de départ et la semaine du trajet
        $stmtDepart = $pdo->prepare("SELECT JourDepart, Semaine FROM Départ WHERE IdTrajet = :IdTrajet");
    
        // Liez les paramètres de la requête
        $stmtDepart->bindParam(':IdTrajet', $id);
    
        // Exécutez la requête en passant l'ID du trajet actuel comme paramètre
        $stmtDepart->execute();
    
        // Récupérez les résultats de la requête
        $departDetail = $stmtDepart->fetch(PDO::FETCH_ASSOC);
// Vérifiez s'il y a des résultats
if ($departDetail) {
    // Accédez au jour de départ et à la semaine
    $jourDepart = $departDetail['jourdepart'];
    $semaine = $departDetail['semaine'];
        $convertedDate = getDateFromWeekDay($departureYear, $departDetail['semaine'], $departDetail['jourdepart']);
        
        // Ensure both dates are strings in the same format
        $convertedDateStr = (new DateTime($convertedDate))->format('Y-m-d');
        $departureDateStr = (new DateTime($departureDate))->format('Y-m-d'); 
        if ($convertedDateStr === $departureDateStr) {
            $validTrips[] = $t;
        }
    }}

    if (empty($validTrips)) {
        echo "<p>Aucun trajet ne correspond à la date sélectionnée.</p>";

    } else {
        $_SESSION['trajets'] = $trajets;
        echo "<p>Trouvé " . count($trajets) . " trajet(s) correspondant à vos critères et dates.</p>";
    }
}
}
elseif ($_SERVER["REQUEST_METHOD"] != "POST") {
    // Si des données POST ont été soumises mais tous les champs ne sont pas remplis
    echo "<p>Veuillez remplir tous les champs pour effectuer une recherche.</p>";

}

// Function to sanitize input data
/*function clean_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}*/
// fonction qui convertit jour x de la semaine y en une date :
function getDateFromWeekDay($year, $weekNumber, $weekDay) {
    // Validate input
    if ($weekNumber < 1 || $weekDay < 1 || $weekDay > 7) {
        throw new InvalidArgumentException("Week number and week day must be valid: weekNumber >= 1, 1 <= weekDay <= 7");
    }

    // Créer la date correspondant au premier jour de l'année
    $date = new DateTime("{$year}-01-01");

    // Calculate the offset to the first day of the first week
    $firstDayOfWeek = (int) $date->format('N');  // 1 (Monday) to 7 (Sunday)
    $offsetToFirstDayOfWeek = 1 - $firstDayOfWeek;

    // Adjust the date to the first day of the first week
    $date->modify("{$offsetToFirstDayOfWeek} days");

    // Ajouter les semaines nécessaires, moins une car on est déjà au début de la première semaine
    $weeksToAdd = $weekNumber - 1;
    $daysToAdd = ($weeksToAdd * 7) + ($weekDay - 1);

    // Ajouter les jours au début de la première semaine
    $date->modify("{$daysToAdd} days");

    return $date->format('Y-m-d'); // Format retour YYYY-MM-DD
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
        <!-- Meta Tags -->
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="keywords" content="Site keywords here">
		<meta name="description" content="">
		<meta name='copyright' content=''>
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		
		<!-- Title -->
        <title>Projet BD-PHP-WEB Plateforme Co-Voiturage : Index</title>
		
		<!-- Favicon -->
        <link rel="icon" href="images/favicon.png">
		
		<!-- Google Fonts -->
		<link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<!-- Nice Select CSS -->
		<link rel="stylesheet" href="css/nice-select.css">
		<!-- Font Awesome CSS -->
        <link rel="stylesheet" href="css/font-awesome.min.css">
		<!-- icofont CSS -->
        <link rel="stylesheet" href="css/icofont.css">
		<!-- Slicknav -->
		<link rel="stylesheet" href="css/slicknav.min.css">
		<!-- Owl Carousel CSS -->
        <link rel="stylesheet" href="css/owl-carousel.css">
		<!-- Datepicker CSS -->
		<link rel="stylesheet" href="css/datepicker.css">
		<!-- Animate CSS -->
        <link rel="stylesheet" href="css/animate.min.css">
		<!-- Magnific Popup CSS -->
        <link rel="stylesheet" href="css/magnific-popup.css">
		
		<!-- Medipro CSS -->
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="css/responsive.css">
     <style>
        /* Ajoutez ces styles dans votre fichier style.css */
.filter-section {
    background-color: #f9f9f9;
    border-radius: 8px;
    padding: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    border: 8px solid #6B8E23;    
}

.checkbox-group {
    margin-bottom: 10px; 
}

.checkbox-group input[type="checkbox"] {
    margin-right: 5px;      
}

button[type="submit"] {
    background-color: #6B8E23;
    color: #fff;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

button[type="submit"]:hover {
    background-color: #6B8E23;
}
/* Styles pour la section de recherche */
.filter-container {
    background-color: #f8f9fa;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    border: 8px solid #6B8E23;    

}

.filter-container form {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 10px;
}

.filter-container label {
    font-weight: bold;
    
}

.filter-container input[type="text"],
.filter-container input[type="date"],
.filter-container input[type="number"] {
    width: 100%;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    
}

.filter-container button {
    padding: 10px 20px;
    background-color:#6B8E23;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;
  

}

.filter-container button:hover {
    background-color: #0056b3;
}
/* Styles pour la section des résultats */
.trips-container {
    display: flex;
    flex-direction: column;
    gap: 20px; /* Espace entre les cartes */
    padding: 20px; /* Espace autour des cartes */
    background-color: #f4f4f4; /* Couleur de fond légère pour le conteneur */
}

.trip-card {
    background-color: #fff; /* Fond blanc pour chaque carte */
    border: 1px solid #ccc; /* Bordure légère pour chaque carte */
    box-shadow: 0 2px 5px rgba(0,0,0,0.1); /* Ombre subtile pour la profondeur */
    padding: 15px; /* Espace intérieur pour chaque carte */
    text-decoration: none; /* Supprime le soulignement des liens */
    color: black; /* Couleur du texte */
}

.trip-card:hover {
    box-shadow: 0 5px 15px rgba(0,0,0,0.2); /* Ombre plus prononcée au survol */
    transition: box-shadow 0.3s; /* Transition lisse pour l'ombre */
}

.trip-details h2 {
    margin-top: 0; /* Supprime la marge en haut du titre */
    color: #4CAF50; /* Couleur spéciale pour les titres */
}

.trip-details p {
    margin-bottom: 5px; /* Réduit l'espace en dessous de chaque paragraphe */
    font-size: 14px; /* Taille de police standard pour les détails */
}.trip-card:hover {
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}



.trip-details h2 {
    margin-bottom: 10px;
    font-size: 18px; /* Taille de la police pour le titre */
}

.trip-details p {
    margin-bottom: 5px;
    font-size: 16px; /* Taille de la police pour le texte */
}


     </style>
</head>
    <body>
		<!-- Preloader -->
        <div class="preloader">
            <div class="loader">
                <div class="loader-outter"></div>
                <div class="loader-inner"></div>

                <div class="indicator"> 
                    <svg width="16px" height="12px">
                        <polyline id="back" points="1 6 4 6 6 11 10 1 12 6 15 6"></polyline>
                        <polyline id="front" points="1 6 4 6 6 11 10 1 12 6 15 6"></polyline>
                    </svg>
                </div>
            </div>
        </div>
        <!-- End Preloader -->
	
		<!-- Header Area -->
		<header class="header" >
			<!-- Header Inner -->
			<div class="header-inner">
				<div class="container">
					<div class="inner">
						<div class="row">
							<div class="col-lg-3 col-md-3 col-12">
								<!-- Start Logo -->
								<div class="logo">
									<a href="index.html"><img src="images/logo.png" alt="#"></a>
								</div>
								<!-- End Logo -->
								<!-- Mobile Nav -->
								<div class="mobile-nav"></div>
								<!-- End Mobile Nav -->
							</div>
							<div class="col-lg-7 col-md-9 col-12">
								<!-- Main Menu -->
								<div class="main-menu">
									<nav class="navigation">
										<ul class="nav menu">
											<li><a href="index.html">Accueil</a></li>
											<li><a href="recherche.html">Recherche</a></li>
											<li><a href="boutique.html">Boutique</a></li>
											<li><a href="" class="typewrite" data-period="2000" data-type='[ "Bienvenue chez CovoiTECH", "Votre trajet, notre priorité", "Ensemble sur la route !" ]'></a></li>
										</ul>
									</nav>
								</div>
								<!--/ End Main Menu -->
							</div>
							<div class="col-lg-1 col-12">
								<div class="get-quote">
									<a href="sign-in.html" class="btn">Connexion</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--/ End Header Inner -->
		</header>
        <div class="container">
            <!-- Header Section -->
            <header class="row mb-4">
                <div class="col">
                    <!-- Your Logo here -->
                </div>
            </header>

            <!-- Search Section -->
            <section class="row mb-3">
            <div class="col">
                <div class="filter-container">
                    <form method="POST" id="search-form">
                        <div class="form-row">
                            <div class="form-group col-md-3">
                                <label for="departureDate">Date de départ:</label>
                                <input type="date" id="departureDate" name="departureDate" class="form-control" required>
                            </div>
                            <div class="form-group col-md-3">
                                <label for="VilleDepart">Ville de départ:</label>
                                <input type="text" id="VilleDepart" name="VilleDepart" class="form-control" required>
                            </div>
                            <div class="form-group col-md-3">
                                <label for="VilleArrivee">Ville d'arrivée:</label>
                                <input type="text" id="VilleArrivee" name="VilleArrivee" class="form-control" required>
                            </div>
                            <div class="form-group col-md-2">
                                <label for="PlaceDispo">Nombre de Passagers:</label>
                                <input type="number" id="PlaceDispo" name="PlaceDispo" class="form-control" required min="1">
                            </div>
                            <div class="form-group col-md-1">
                                <label for="">&nbsp;</label>
                                <button type="submit" class="btn btn-primary btn-block">Rechercher</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>

        <!-- Results Section -->
        <div class="row">
            <div class="col">
            <div id="trip-results">
                <?php
                // Check if there are any search results
                if (!empty($_SESSION['trajets'])) {
                    // Retrieve the results from the session
                    $trajets = $_SESSION['trajets'];


                    echo "<div class='trips-container'>"; // Container for all trips

                    // Display the results
                    foreach ($trajets as $result) {
                        // URL where the client will be redirected when clicking on a trip
                        $detailPageUrl = "voyage.php?tripId=" . urlencode($result['idtrajet']);

                        echo "<a href='{$detailPageUrl}' class='trip-card'>";
                        echo "<div class='trip-details'>";

                        // Display trip details using lowercase keys
                        echo "<h2><strong>Voyage de " . htmlspecialchars($result['villedepart']) . " à " . htmlspecialchars($result['villearrivee']) . "</strong></h2>";
                        echo "<p><strong>Adresse de départ:</strong> " . htmlspecialchars($result['numruedepart']) . " " . htmlspecialchars($result['nomruedepart']) . ", " . htmlspecialchars($result['codepostaldepart']) . ", " . htmlspecialchars($result['villedepart']) . "</p>";
                        echo "<p><strong>Nombre de passagers disponibles:</strong> " . htmlspecialchars($result['placedispo']) . "</p>";

                        echo "</div>"; // Closing div for trip-details
                        echo "</a>"; // Closing tag for the link
                    }

                    echo "</div>"; // Closing div for trips-container

                    // Clear the results from the session after displaying them
                    unset($_SESSION['trajets']);
                }
                ?>
            </div>
            </div>

            <aside class="col-md-3 mb-3">
                <div class="filter-section">
                    <form id="filter-form">
                        <h3>Trier Par:</h3>
                        
                        <!-- Checkbox filters for sorting options -->
                        <div class="checkbox-group">
                            <label for="earliest-departure">
                                <input type="checkbox" id="earliest-departure" name="sort" value="earliest"> Départ le plus tôt
                            </label>
                        </div>
                        
                        <div class="checkbox-group">
                            <label for="shortest-trip">
                                <input type="checkbox" id="shortest-trip" name="sort" value="shortest"> Trajet le plus court
                            </label>
                        </div>
                        
                        <div class="checkbox-group">
                            <label for="direct-only">
                                <input type="checkbox" id="direct-only" name="sort" value="direct"> Trajets directs uniquement
                            </label>
                        </div>
                        
                        <div class="checkbox-group">
                            <label for="high-rating">
                                <input type="checkbox" id="high-rating" name="sort" value="high-rating"> Profil +4 étoiles
                            </label>
                        </div>
                
                        <h3>Heure de départ:</h3>
                        
                        <!-- Checkbox filters for departure times -->
                        <div class="checkbox-group">
                            <label for="before-6">
                                <input type="checkbox" id="before-6" name="departure-time" value="before-6"> Avant 06:00
                            </label>
                        </div>
                        
                        <div class="checkbox-group">
                            <label for="between-6-12">
                                <input type="checkbox" id="between-6-12" name="departure-time" value="6-12"> 06:00 - 12:00
                            </label>
                        </div>
                        
                        <div class="checkbox-group">
                            <label for="between-12-18">
                                <input type="checkbox" id="between-12-18" name="departure-time" value="12-18"> 12:01 - 18:00
                            </label>
                        </div>
                        
                        <div class="checkbox-group">
                            <label for="after-18">
                                <input type="checkbox" id="after-18" name="departure-time" value="after-18"> Après 18:00
                            </label>
                        </div>
                
                        <button type="submit">Appliquer les filtres</button>
                    </form>
                </div>
                
            </aside>
        </div>

		<!-- Footer Area -->
		<footer id="footer" class="footer ">
			<div class="footer-top">
				<div class="container">
					<div class="row">
						<div class="col-lg-9 col-md-6 col-12">
							<div class="single-footer">
								<h2>À propos</h2>
								<p>Notre site simule une plateforme intuitive où les utilisateurs peuvent proposer ou rechercher des trajets, gérer leurs réservations et interagir avec d’autres membres. L’accent a été mis sur la simplicité d’utilisation, la sécurité des données et la  Création d’une expérience utilisateur engageante. </p>
								<p><br>Ce site web de covoiturage est le fruit d’un projet académique mené par un groupe d'étudiants de l’UPSSITECH, développé en PHP, HTML, CSS, Javascript et appuyé par une base de données robuste. Il sert principalement de démonstration des compétences techniques acquises durant notre année universitaire et n’est pas destiné à un usage commercial.</p>
							</div>
						</div>
						<div class="col-lg-3 col-md-6 col-12">
							<div class="single-footer f-link">
								<h2>Membres de l’équipe</h2>
								<p>-> Chehab MOSAAD
									<br>-> Nizar SLAMA SEFI
									<br>-> Miniar JABRI
									<br>-> Lina AHNOUDJ 
									<br>-> Linda BEDOUI
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
		<!--/ End Footer Area -->
		
		<!-- jquery Min JS -->
        <script src="js/jquery.min.js"></script>
		<!-- jquery Migrate JS -->
		<script src="js/jquery-migrate-3.0.0.js"></script>
		<!-- jquery Ui JS -->
		<script src="js/jquery-ui.min.js"></script>
		<!-- Easing JS -->
        <script src="js/easing.js"></script>
		<!-- Color JS -->
		<script src="js/colors.js"></script>
		<!-- Popper JS -->
		<script src="js/popper.min.js"></script>
		<!-- Bootstrap Datepicker JS -->
		<script src="js/bootstrap-datepicker.js"></script>
		<!-- Jquery Nav JS -->
        <script src="js/jquery.nav.js"></script>
		<!-- Slicknav JS -->
		<script src="js/slicknav.min.js"></script>
		<!-- ScrollUp JS -->
        <script src="js/jquery.scrollUp.min.js"></script>
		<!-- Niceselect JS -->
		<script src="js/niceselect.js"></script>
		<!-- Tilt Jquery JS -->
		<script src="js/tilt.jquery.min.js"></script>
		<!-- Owl Carousel JS -->
        <script src="js/owl-carousel.js"></script>
		<!-- counterup JS -->
		<script src="js/jquery.counterup.min.js"></script>
		<!-- Steller JS -->
		<script src="js/steller.js"></script>
		<!-- Wow JS -->
		<script src="js/wow.min.js"></script>
		<!-- Magnific Popup JS -->
		<script src="js/jquery.magnific-popup.min.js"></script>
		<!-- Counter Up CDN JS -->
		<script src="http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>
		<!-- Bootstrap JS -->
		<script src="js/bootstrap.min.js"></script>
		<!-- Main JS -->
		<script src="js/main.js"></script>
    </body>
</html>