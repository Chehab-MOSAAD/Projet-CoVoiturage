<?php
require_once 'classes/Database.php';

$database = new Database();
$conn = $database->getConnection();

if ($conn === null) {
    die('Connection failed: Unable to connect to the database');
}

try {
    // Query for total users and additional statistics
    $queryUtilisateur = "
        SELECT 
            COUNT(*) as total, 
            SUM(CASE WHEN Handicap THEN 1 ELSE 0 END) as handicaps,
            SUM(CASE WHEN Fumeur THEN 1 ELSE 0 END) as fumeurs,
            SUM(CASE WHEN Sexe = 'M' THEN 1 ELSE 0 END) as males,
            SUM(CASE WHEN Sexe = 'F' THEN 1 ELSE 0 END) as females,
            SUM(CASE WHEN EXTRACT(YEAR FROM AGE(MAKE_DATE(Annee, Mois, Jour))) > 22 THEN 1 ELSE 0 END) as above_22,
            SUM(CASE WHEN EXTRACT(YEAR FROM AGE(MAKE_DATE(Annee, Mois, Jour))) <= 22 THEN 1 ELSE 0 END) as under_22
        FROM Utilisateur";
    $stmtUtilisateur = $database->runQuery($queryUtilisateur);
    $utilisateur = $stmtUtilisateur->fetch(PDO::FETCH_ASSOC);

    // Query for total drivers
    $queryConducteur = "SELECT COUNT(*) as total FROM Conducteur";
    $stmtConducteur = $database->runQuery($queryConducteur);
    $conducteur = $stmtConducteur->fetch(PDO::FETCH_ASSOC);

    // Query for total trips
    $queryTrajet = "SELECT COUNT(*) as total FROM Trajet";
    $stmtTrajet = $database->runQuery($queryTrajet);
    $trajet = $stmtTrajet->fetch(PDO::FETCH_ASSOC);

    // Query for completed trips
    $queryTrajetDone = "
        SELECT COUNT(*) as total 
        FROM Trajet t
        INNER JOIN Départ d ON t.IdTrajet = d.IdTrajet
        WHERE (d.Semaine * 7 + d.JourDepart) < (EXTRACT(WEEK FROM CURRENT_DATE) * 7 + EXTRACT(ISODOW FROM CURRENT_DATE))";
    $stmtTrajetDone = $database->runQuery($queryTrajetDone);
    $trajetDone = $stmtTrajetDone->fetch(PDO::FETCH_ASSOC);

    // Query for future trips
    $queryTrajetFuture = "
        SELECT COUNT(*) as total 
        FROM Trajet t
        INNER JOIN Départ d ON t.IdTrajet = d.IdTrajet
        WHERE (d.Semaine * 7 + d.JourDepart) >= (EXTRACT(WEEK FROM CURRENT_DATE) * 7 + EXTRACT(ISODOW FROM CURRENT_DATE))";
    $stmtTrajetFuture = $database->runQuery($queryTrajetFuture);
    $trajetFuture = $stmtTrajetFuture->fetch(PDO::FETCH_ASSOC);

    // Query for total boutique items
    $queryBoutique = "SELECT COUNT(*) as total FROM Boutique";
    $stmtBoutique = $database->runQuery($queryBoutique);
    $boutique = $stmtBoutique->fetch(PDO::FETCH_ASSOC);

    // Query for total comments from passengers
    $queryCommentRes = "SELECT COUNT(*) as total FROM CommenterReservation";
    $stmtCommentRes = $database->runQuery($queryCommentRes);
    $commentRes = $stmtCommentRes->fetch(PDO::FETCH_ASSOC);

    // Query for total comments from drivers
    $queryCommentPass = "SELECT COUNT(*) as total FROM CommenterPassager";
    $stmtCommentPass = $database->runQuery($queryCommentPass);
    $commentPass = $stmtCommentPass->fetch(PDO::FETCH_ASSOC);

    // Query for total cars
    $queryVoiture = "SELECT COUNT(*) as total FROM Voiture";
    $stmtVoiture = $database->runQuery($queryVoiture);
    $voiture = $stmtVoiture->fetch(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Database query error: " . $e->getMessage());
}
?>

<!doctype html>
<html class="no-js" lang="zxx">
    <head>
        <!-- Meta Tags -->
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="keywords" content="Site keywords here">
		<meta name="description" content="">
		<meta name='copyright' content=''>
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		
		<!-- Title -->
        <title>Projet BD-PHP-WEB Plateforme Co-Voiturage : Accueil Administrateur</title>
		
		<!-- Favicon -->
        <link rel="icon" href="images/favicon.png">
		
		<!-- Google Fonts -->
		<link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<!-- Nice Select CSS -->
		<link rel="stylesheet" href="css/nice-select.css">
		<!-- Font Awesome CSS -->
        <link rel="stylesheet" href="css/font-awesome.min.css">
		<!-- icofont CSS -->
        <link rel="stylesheet" href="css/icofont.css">
		<!-- Slicknav -->
		<link rel="stylesheet" href="css/slicknav.min.css">
		<!-- Owl Carousel CSS -->
        <link rel="stylesheet" href="css/owl-carousel.css">
		<!-- Datepicker CSS -->
		<link rel="stylesheet" href="css/datepicker.css">
		<!-- Animate CSS -->
        <link rel="stylesheet" href="css/animate.min.css">
		<!-- Magnific Popup CSS -->
        <link rel="stylesheet" href="css/magnific-popup.css">
		
		<!-- Medipro CSS -->
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="css/responsive.css">
		
    </head>
    <body>
	
		<!-- Preloader -->
        <div class="preloader">
            <div class="loader">
                <div class="loader-outter"></div>
                <div class="loader-inner"></div>

                <div class="indicator"> 
                    <svg width="16px" height="12px">
                        <polyline id="back" points="1 6 4 6 6 11 10 1 12 6 15 6"></polyline>
                        <polyline id="front" points="1 6 4 6 6 11 10 1 12 6 15 6"></polyline>
                    </svg>
                </div>
            </div>
        </div>
        <!-- End Preloader -->
	
		<!-- Header Area -->
		<header class="header" >
			<!-- Header Inner -->
			<div class="header-inner">
				<div class="container">
					<div class="inner">
						<div class="row">
							<div class="col-lg-3 col-md-3 col-12">
								<!-- Start Logo -->
								<div class="logo">
									<a href="Admin_index.php"><img src="images/logo.png" alt="#"></a>
								</div>
								<!-- End Logo -->
								<!-- Mobile Nav -->
								<div class="mobile-nav"></div>
								<!-- End Mobile Nav -->
							</div>
							<div class="col-lg-7 col-md-9 col-12">
								<!-- Main Menu -->
								<div class="main-menu">
									<nav class="navigation">
										<ul class="nav menu">
											<li><a href="Admin_index.php">Accueil</a></li>
											<li><a href="..\Linda\admin_requests.php">Alertes</a></li>
											<li><a href="..\Linda\contacts.php">Messagrie</a></li>
											<li><a href="" class="typewrite" data-period="2000" data-type='[ "Bienvenue chez CovoiTECH", "Votre trajet, notre priorité", "Ensemble sur la route !" ]'></a></li>
										</ul>
									</nav>
								</div>
								<!--/ End Main Menu -->
							</div>
							<div class="col-lg-1 col-12">
								<div class="get-quote">
									<a href="Visiteur_index.html" class="btn">Déconnexion</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--/ End Header Inner -->
		</header>

		<section class="pricing-table section">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="section-title">
							<h2>Bienvenue Administrateur !</h2>
						</div>
					</div>
				</div>
				<div class="row">
					<!-- Single Table -->
					<div class="col-lg-4 col-md-12 col-12">
						<div class="single-table">
							<!-- Table Head -->
							<div class="table-head">
								<div class="icon">
									<i class="icofont-user"></i>
								</div>
								<h4 class="title">Utilisateurs</h4>
								<div class="price">
									<p class="amount"><?= $utilisateur['total'] ?><span> Total</span></p>
								</div>  
							</div>
							<!-- Table List -->
							<ul class="table-list">
								<li><i class="icofont icofont-ui-check"></i> Dont <?= $utilisateur['handicaps'] ?> avec handicap</li>
								<li><i class="icofont icofont-ui-check"></i> Dont <?= $utilisateur['fumeurs'] ?> fumeurs</li>
								<li><i class="icofont icofont-ui-check"></i> Dont <?= $utilisateur['males'] ?> hommes</li>
								<li><i class="icofont icofont-ui-check"></i> Dont <?= $utilisateur['females'] ?> femmes</li>
								<li><i class="icofont icofont-ui-check"></i> Dont <?= $utilisateur['above_22'] ?> au-dessus de 22 ans</li>
								<li><i class="icofont icofont-ui-check"></i> Dont <?= $utilisateur['under_22'] ?> au-dessous de 22 ans</li>
								<li><i class="icofont icofont-ui-check"></i> Dont <?= $conducteur['total'] ?> conducteurs</li>
							</ul>
							<div class="table-bottom">
								<a class="btn" href="ViewAllUtilisateur.php">Gérer</a>
							</div>
							<!-- Table Bottom -->
						</div>
					</div>
					<!-- End Single Table-->
					<!-- Single Table for Trajets -->
					<div class="col-lg-4 col-md-12 col-12">
						<div class="single-table">
							<!-- Table Head -->
							<div class="table-head">
								<div class="icon">
									<i class="icofont-car-alt-1"></i>
								</div>
								<h4 class="title">Trajets</h4>
								<div class="price">
									<p class="amount"><?= $trajet['total'] ?><span> Total</span></p>
								</div>  
							</div>
							<!-- Table List -->
							<ul class="table-list">
								<li><i class="icofont icofont-ui-check"></i> Dont <?= $trajetDone['total'] ?> trajets effectués</li>
								<li><i class="icofont icofont-ui-check"></i> Dont <?= $trajetFuture['total'] ?> trajets à venir</li>
							</ul>
							<div class="table-bottom">
								<a class="btn" href="ViewAllTrajets.php">Gérer</a>
							</div>
							<!-- Table Bottom -->
						</div>
					</div>
					<!-- Single Table -->
					<div class="col-lg-4 col-md-12 col-12">
						<div class="single-table">
							<!-- Table Head -->
							<div class="table-head">
								<div class="icon">
									<i class="icofont icofont-shopping-cart"></i>
								</div>
								<h4 class="title">Cadeaux</h4>
								<div class="price">
									<p class="amount"><?= $boutique['total'] ?><span> Total</span></p>
								</div>	
							</div>
							<div class="table-bottom">
								<a class="btn" href="ViewAllBoutique.php">Gérer</a>
							</div>
							<!-- Table Bottom -->
						</div>
					</div>
					<!-- End Single Table-->
					<!-- Single Table for Comments from Passengers -->
					<div class="col-lg-4 col-md-12 col-12">
						<div class="single-table">
							<!-- Table Head -->
							<div class="table-head">
								<div class="icon">
									<i class="icofont-comment"></i>
								</div>
								<h4 class="title">Commentaires des Passagers</h4>
								<div class="price">
									<p class="amount"><?= $commentRes['total'] ?><span> Total</span></p>
								</div>  
							</div>
							<div class="table-bottom">
								<a class="btn" href="viewallcommentairesres.php">Gérer</a>
							</div>
							<!-- Table Bottom -->
						</div>
					</div>

					<!-- Single Table for Comments from Drivers -->
					<div class="col-lg-4 col-md-12 col-12">
						<div class="single-table">
							<!-- Table Head -->
							<div class="table-head">
								<div class="icon">
									<i class="icofont-comment"></i>
								</div>
								<h4 class="title">Commentaires des Conducteurs</h4>
								<div class="price">
									<p class="amount"><?= $commentPass['total'] ?><span> Total</span></p>
								</div>  
							</div>
							<div class="table-bottom">
								<a class="btn" href="viewallcommentairespass.php">Gérer</a>
							</div>
							<!-- Table Bottom -->
						</div>
					</div>

					<!-- Single Table for Cars -->
					<div class="col-lg-4 col-md-12 col-12">
						<div class="single-table">
							<!-- Table Head -->
							<div class="table-head">
								<div class="icon">
									<i class="icofont-car"></i>
								</div>
								<h4 class="title">Voitures</h4>
								<div class="price">
									<p class="amount"><?= $voiture['total'] ?><span> Total</span></p>
								</div>  
							</div>
							<div class="table-bottom">
								<a class="btn" href="viewallvoitures.php">Gérer</a>
							</div>
							<!-- Table Bottom -->
						</div>
					</div>					
				</div>	
			</div>	
		</section>	
		
		<!-- Footer Area -->
		<footer id="footer" class="footer ">
			<div class="footer-top">
				<div class="container">
					<div class="row">
						<div class="col-lg-9 col-md-6 col-12">
							<div class="single-footer">
								<h2>À propos</h2>
								<p>Notre site simule une plateforme intuitive où les utilisateurs peuvent proposer ou rechercher des trajets, gérer leurs réservations et interagir avec d’autres membres. L’accent a été mis sur la simplicité d’utilisation, la sécurité des données et la  Création d’une expérience utilisateur engageante. </p>
								<p><br>Ce site web de covoiturage est le fruit d’un projet académique mené par un groupe d'étudiants de l’UPSSITECH, développé en PHP, HTML, CSS, Javascript et appuyé par une base de données robuste. Il sert principalement de démonstration des compétences techniques acquises durant notre année universitaire et n’est pas destiné à un usage commercial.</p>
							</div>
						</div>
						<div class="col-lg-3 col-md-6 col-12">
							<div class="single-footer f-link">
								<h2>Membres de l’équipe</h2>
								<p>-> Chehab MOSAAD
									<br>-> Nizar SLAMA SEFI
									<br>-> Miniar JABRI
									<br>-> Lina AHNOUDJ 
									<br>-> Linda BEDOUI
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
		<!--/ End Footer Area -->
		
		<!-- jquery Min JS -->
        <script src="js/jquery.min.js"></script>
		<!-- jquery Migrate JS -->
		<script src="js/jquery-migrate-3.0.0.js"></script>
		<!-- jquery Ui JS -->
		<script src="js/jquery-ui.min.js"></script>
		<!-- Easing JS -->
        <script src="js/easing.js"></script>
		<!-- Color JS -->
		<script src="js/colors.js"></script>
		<!-- Popper JS -->
		<script src="js/popper.min.js"></script>
		<!-- Bootstrap Datepicker JS -->
		<script src="js/bootstrap-datepicker.js"></script>
		<!-- Jquery Nav JS -->
        <script src="js/jquery.nav.js"></script>
		<!-- Slicknav JS -->
		<script src="js/slicknav.min.js"></script>
		<!-- ScrollUp JS -->
        <script src="js/jquery.scrollUp.min.js"></script>
		<!-- Niceselect JS -->
		<script src="js/niceselect.js"></script>
		<!-- Tilt Jquery JS -->
		<script src="js/tilt.jquery.min.js"></script>
		<!-- Owl Carousel JS -->
        <script src="js/owl-carousel.js"></script>
		<!-- counterup JS -->
		<script src="js/jquery.counterup.min.js"></script>
		<!-- Steller JS -->
		<script src="js/steller.js"></script>
		<!-- Wow JS -->
		<script src="js/wow.min.js"></script>
		<!-- Magnific Popup JS -->
		<script src="js/jquery.magnific-popup.min.js"></script>
		<!-- Counter Up CDN JS -->
		<script src="http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>
		<!-- Bootstrap JS -->
		<script src="js/bootstrap.min.js"></script>
		<!-- Main JS -->
		<script src="js/main.js"></script>
    </body>
</html>