--  Création de la table messagerie -- testé et c'est bon 
CREATE TABLE Messagerie (
   IdSession INT,
   Message TEXT,
   PRIMARY KEY(IdSession)
);

-- Création de la table visiteur -- testé et c'est bon 
CREATE TABLE Visiteur(
   IdTemp VARCHAR(50),
   PRIMARY KEY(IdTemp)
);

-- Création de la table admin -- testé et c'est bon 
CREATE TABLE Administrateur(
   IdAdm INT,
   NomAdm VARCHAR(50),
   PrenomAdm VARCHAR(50),
   Mail VARCHAR(100) UNIQUE NOT NULL CHECK (Mail SIMILAR TO '%@%\.%'),  -- Utilisation de SIMILAR TO pour la vérification d'email
   MotDePasse VARCHAR(100) NOT NULL CHECK (MotDePasse ~ '.*[a-z]+.*' AND MotDePasse ~ '.*[A-Z]+.*'),
   PRIMARY KEY(IdAdm)
);

-- Création de la table Date -- testé et c'est bon 
CREATE TABLE LaDate(
   Jour INT CHECK (Jour BETWEEN 1 AND 31),
   Mois INT CHECK (Mois BETWEEN 1 AND 12),
   Annee INT CHECK (Annee > 0),
   Heure TIME ,
   PRIMARY KEY(Jour, Mois, Annee)
);

-- Création de la table Calendrier -- testé et c'est bon 
CREATE TABLE Calendrier(
   HeureDepart TIME,
   PRIMARY KEY(HeureDepart)
);

-- Création de la table jour -- testé et c'est bon 
CREATE TABLE Jour(
   JourDepart INT NOT NULL CHECK (JourDepart BETWEEN 1 AND 7),
   JourArrivee INT NOT NULL CHECK (JourArrivee BETWEEN 1 AND 7),
   Semaine INT NOT NULL CHECK (Semaine BETWEEN 1 AND 52),
   PRIMARY KEY(JourDepart, JourArrivee, Semaine)
);

-- Création de la table boutique -- testé et c'est bon 
CREATE TABLE Boutique(
   IdCadeau INT,
   NomCadeau VARCHAR(100),
   DescriptionCadeau TEXT,
   PointsNecessaires INT CHECK (PointsNecessaires >= 0),
   PRIMARY KEY(IdCadeau)
);

-- Création de la table Escale -- testé et c'est bon 
CREATE TABLE Escale(
   IdLieu VARCHAR(50),
   NomRue VARCHAR(100) NOT NULL CHECK (NomRue ~ '^[A-Za-z ]+$'),
   NumRue INT NOT NULL CHECK (NumRue BETWEEN 1 AND 9999),
   CodePostal VARCHAR(5) NOT NULL CHECK (CodePostal ~ '^\d{5}$'),
   Accessibilite BOOLEAN NOT NULL,
   PRIMARY KEY(IdLieu)
);

-- Création de la table Historique -- testé et c'est bon 
CREATE TABLE Historique(
   IdHistorique INT,
   PRIMARY KEY(IdHistorique)
);

-- Création de la table Utilisateur -- testé et c'est bon
CREATE TABLE Utilisateur(
   IdUtilisateur SERIAL PRIMARY KEY,
   Mail VARCHAR(100) UNIQUE NOT NULL CHECK (Mail SIMILAR TO '%@%\.%'),  -- Utilisation de SIMILAR TO pour la vérification d'email
   MotDePasse VARCHAR(100) NOT NULL CHECK (MotDePasse ~ '.*[a-z]+.*' AND MotDePasse ~ '.*[A-Z]+.*'),
   Nom VARCHAR(100) NOT NULL CHECK (Nom ~ '^[A-Za-z]+$'),
   Prenom VARCHAR(100) NOT NULL CHECK (Prenom ~ '^[A-Za-z]+$'),
   Sexe CHAR(1) NOT NULL CHECK (Sexe IN ('M', 'F')),
   Tel VARCHAR(10) NOT NULL CHECK (length(Tel) = 10 AND Tel ~ '^[0-9]+$' AND Tel LIKE '0%'),  -- Ajustement à 10 chiffres pour Tel
   Handicap BOOLEAN NOT NULL,
   NotePassager INT CHECK (NotePassager BETWEEN 0 AND 5),
   LangueParle1 VARCHAR(50) NOT NULL CHECK (LangueParle1 ~ '^[A-Za-z]+$'),
   LangueParle2 VARCHAR(50) CHECK (LangueParle2 ~ '^[A-Za-z]*$'),
   Fumeur BOOLEAN NOT NULL,
   Jour INT NOT NULL CHECK (Jour BETWEEN 1 AND 31),
   Mois INT NOT NULL CHECK (Mois BETWEEN 1 AND 12),
   Annee INT NOT NULL CHECK (Annee > 0)
   FOREIGN KEY(Jour, Mois, Annee) REFERENCES LaDate(Jour, Mois, Annee)
);

-- Création de la table conducteur -- testé et c'est bon
CREATE TABLE Conducteur(
   NumPermis VARCHAR(50) NOT NULL,
   Points INT CHECK (Points BETWEEN 0 AND 15),
   NoteConducteur FLOAT,
   IdUtilisateur INT NOT NULL,
   PRIMARY KEY(NumPermis),
   FOREIGN KEY(IdUtilisateur) REFERENCES Utilisateur(IdUtilisateur)
);

-- Création de la table voiture -- testé et c'est bon
CREATE TABLE Voiture(
   Matricule VARCHAR(50) CHECK (Matricule ~ '^[A-Z0-9]+$'),
   Marque VARCHAR(50) NOT NULL CHECK (Marque ~ '^[A-Za-z0-9 ]+$'),
   Modele VARCHAR(50) NOT NULL CHECK (Modele ~ '^[A-Za-z0-9 ]+$'),
   Type VARCHAR(50) NOT NULL CHECK (Type IN ('SUV', 'Berline', 'Compacte', 'Monospace')),
   Couleur VARCHAR(50) NOT NULL CHECK (Couleur IN ('bleu', 'violet', 'rose', 'rouge', 'orange', 'jaune', 'vert', 'noir', 'marron', 'gris', 'aluminium', 'argent', 'blanc')),
   NbrPlace INT NOT NULL CHECK (NbrPlace > 0 AND NbrPlace <= 100),
   Carburant VARCHAR(50) NOT NULL CHECK (Carburant IN ('essence', 'diesel', 'éthanol', 'gaz', 'électrique', 'hybride')),
   NumPermis VARCHAR(50) NOT NULL,
   PRIMARY KEY(Matricule),
   FOREIGN KEY(NumPermis) REFERENCES Conducteur(NumPermis)
);

-- Création de la table trajet -- testé et c'est bon
CREATE TABLE Trajet(
   IdTrajet INT,
   VilleDepart VARCHAR(100) NOT NULL CHECK (VilleDepart ~ '^[A-Za-z ]+$'),
   CodePostalDepart VARCHAR(10) NOT NULL CHECK (CodePostalDepart ~ '^\d{5}$'),
   NomRueDepart VARCHAR(50) NOT NULL CHECK (NomRueDepart ~ '^[A-Za-z ]+$'),
   NumRueDepart INT NOT NULL CHECK (NumRueDepart BETWEEN 1 AND 9999),
   VilleArrivee VARCHAR(100) NOT NULL CHECK (VilleArrivee ~ '^[A-Za-z ]+$'),
   CodePostalArrivee VARCHAR(5) NOT NULL CHECK (CodePostalArrivee ~ '^\d{5}$'),
   NomRueArrivee VARCHAR(50) NOT NULL CHECK (NomRueArrivee ~ '^[A-Za-z ]+$'),
   NumRueArrivee INT NOT NULL CHECK (NumRueArrivee BETWEEN 1 AND 9999),
   CommentaireTrajetConducteur TEXT,
   PlaceDispo INT CHECK (PlaceDispo > 0),
   Matricule VARCHAR(50) NOT NULL,
   NumPermis VARCHAR(50) NOT NULL,
   PRIMARY KEY(IdTrajet),
   FOREIGN KEY(Matricule) REFERENCES Voiture(Matricule),
   FOREIGN KEY(NumPermis) REFERENCES Conducteur(NumPermis)
);

-- Création de la table Reservation -- testé et c'est bon
CREATE TABLE Reservation(
   IdRes INT,
   ReservationStatus VARCHAR(50),
   NumPermis VARCHAR(50),
   IdTrajet INT,
   PRIMARY KEY(IdRes),
   FOREIGN KEY(NumPermis) REFERENCES Conducteur(NumPermis),
   FOREIGN KEY(IdTrajet) REFERENCES Trajet(IdTrajet)
);

-- Création de la table envoyer -- testé et c'est bon
CREATE TABLE Envoyer(
   IdSession INT,
   IdUtilisateur INT,
   Jour INT NOT NULL CHECK (Jour BETWEEN 1 AND 31),
   Mois INT NOT NULL CHECK (Mois BETWEEN 1 AND 12),
   Annee INT NOT NULL CHECK (Annee > 0),
   PRIMARY KEY(IdSession, IdUtilisateur, Jour, Mois, Annee),
   FOREIGN KEY(IdSession) REFERENCES Messagerie(IdSession),
   FOREIGN KEY(IdUtilisateur) REFERENCES Utilisateur(IdUtilisateur),
   FOREIGN KEY(Jour, Mois, Annee) REFERENCES LaDate(Jour, Mois, Annee)
);

-- Création de la table recevoir -- testé et c'est bon
CREATE TABLE Recevoir(
   IdSession INT,
   IdUtilisateur INT,
   Jour INT NOT NULL CHECK (Jour BETWEEN 1 AND 31),
   Mois INT NOT NULL CHECK (Mois BETWEEN 1 AND 12),
   Annee INT NOT NULL CHECK (Annee > 0),
   PRIMARY KEY(IdSession, IdUtilisateur, Jour, Mois, Annee),
   FOREIGN KEY(IdSession) REFERENCES Messagerie(IdSession),
   FOREIGN KEY(IdUtilisateur) REFERENCES Utilisateur(IdUtilisateur),
   FOREIGN KEY(Jour, Mois, Annee) REFERENCES LaDate(Jour, Mois, Annee)
);

-- Création de la table supprimer -- testé et c'est bon
CREATE TABLE Supprimer(
   IdUtilisateur INT,
   IdAdm INT,
   Jour INT NOT NULL CHECK (Jour BETWEEN 1 AND 31),
   Mois INT NOT NULL CHECK (Mois BETWEEN 1 AND 12),
   Annee INT NOT NULL CHECK (Annee > 0),
   PRIMARY KEY(IdUtilisateur, IdAdm, Jour, Mois, Annee),
   FOREIGN KEY(IdUtilisateur) REFERENCES Utilisateur(IdUtilisateur),
   FOREIGN KEY(IdAdm) REFERENCES Administrateur(IdAdm),
   FOREIGN KEY(Jour, Mois, Annee) REFERENCES LaDate(Jour, Mois, Annee)
);

-- Création de la table reserver -- testé et c'est bon
CREATE TABLE Reserver(
   IdUtilisateur INT,
   IdRes INT,
   PRIMARY KEY(IdUtilisateur, IdRes),
   FOREIGN KEY(IdUtilisateur) REFERENCES Utilisateur(IdUtilisateur),
   FOREIGN KEY(IdRes) REFERENCES Reservation(IdRes)
);

-- Création de la table annulerR -- testé et c'est bon
CREATE TABLE AnnulerR(
   IdUtilisateur INT,
   IdRes INT,
   PRIMARY KEY(IdUtilisateur, IdRes),
   FOREIGN KEY(IdUtilisateur) REFERENCES Utilisateur(IdUtilisateur),
   FOREIGN KEY(IdRes) REFERENCES Reservation(IdRes)
);

-- Création de la table rerchercher -- testé et c'est bon
CREATE TABLE Rechercher(
   IdUtilisateur INT,
   IdTemp VARCHAR(50),
   IdTrajet INT,
   PRIMARY KEY(IdUtilisateur, IdTemp, IdTrajet),
   FOREIGN KEY(IdUtilisateur) REFERENCES Utilisateur(IdUtilisateur),
   FOREIGN KEY(IdTemp) REFERENCES Visiteur(IdTemp),
   FOREIGN KEY(IdTrajet) REFERENCES Trajet(IdTrajet)
);

-- Création de la table départ -- testé et c'est bon
CREATE TABLE Départ(
   IdTrajet INT,
   JourDepart INT NOT NULL CHECK (JourDepart BETWEEN 1 AND 7),
   JourArrivee INT NOT NULL CHECK (JourArrivee BETWEEN 1 AND 7),
   Semaine INT NOT NULL CHECK (Semaine BETWEEN 1 AND 52),
   HeureDepart TIME,
   HeureArrivee TIME,
   PRIMARY KEY(IdTrajet, HeureDepart, JourDepart, JourArrivee, Semaine),
   FOREIGN KEY(IdTrajet) REFERENCES Trajet(IdTrajet),
   FOREIGN KEY(HeureDepart) REFERENCES Calendrier(HeureDepart),
   FOREIGN KEY(JourDepart, JourArrivee, Semaine) REFERENCES Jour(JourDepart, JourArrivee, Semaine)
);

-- Création de la table CommenterReservation -- testé et c'est bon
CREATE TABLE CommenterReservation(
   IdCommentaire SERIAL PRIMARY KEY,
   IdUtilisateur INT,
   IdRes INT,
   CommentairePassager TEXT,
   NoteTrajet INT CHECK (NoteTrajet BETWEEN 0 AND 5),
   FOREIGN KEY(IdUtilisateur) REFERENCES Utilisateur(IdUtilisateur),
   FOREIGN KEY(IdRes) REFERENCES Reservation(IdRes)
);

-- Création de la table MettreJour -- testé et c'est bon
CREATE TABLE MettreJour(
   IdUtilisateur_initial INT,
   IdUtilisateur_actualisé INT,
   Jour INT NOT NULL CHECK (Jour BETWEEN 1 AND 31),
   Mois INT NOT NULL CHECK (Mois BETWEEN 1 AND 12),
   Annee INT NOT NULL CHECK (Annee > 0),
   PRIMARY KEY(IdUtilisateur_initial, IdUtilisateur_actualisé, Jour, Mois, Annee),
   FOREIGN KEY(IdUtilisateur_initial) REFERENCES Utilisateur(IdUtilisateur),
   FOREIGN KEY(IdUtilisateur_actualisé) REFERENCES Utilisateur(IdUtilisateur),
   FOREIGN KEY(Jour, Mois, Annee) REFERENCES LaDate(Jour, Mois, Annee)
);

-- Création de la table Interdire -- testé et c'est bon
CREATE TABLE Interdire(
   IdAdm INT,
   Jour INT NOT NULL CHECK (Jour BETWEEN 1 AND 31),
   Mois INT NOT NULL CHECK (Mois BETWEEN 1 AND 12),
   Annee INT NOT NULL CHECK (Annee > 0),
   NumPermis VARCHAR(50),
   PRIMARY KEY(IdAdm, Jour, Mois, Annee, NumPermis),
   FOREIGN KEY(IdAdm) REFERENCES Administrateur(IdAdm),
   FOREIGN KEY(Jour, Mois, Annee) REFERENCES LaDate(Jour, Mois, Annee),
   FOREIGN KEY(NumPermis) REFERENCES Conducteur(NumPermis)
);

-- Création de la table AnnulerT -- testé et c'est bon
CREATE TABLE AnnulerT(
   IdTrajet INT,
   NumPermis VARCHAR(50),
   PRIMARY KEY(IdTrajet, NumPermis),
   FOREIGN KEY(IdTrajet) REFERENCES Trajet(IdTrajet),
   FOREIGN KEY(NumPermis) REFERENCES Conducteur(NumPermis)
);

-- Création de la table seConnecter -- testé et c'est bon
CREATE TABLE SeConnecter(
   IdUtilisateur INT,
   IdTemp VARCHAR(50),
   PRIMARY KEY(IdUtilisateur, IdTemp),
   FOREIGN KEY(IdUtilisateur) REFERENCES Utilisateur(IdUtilisateur),
   FOREIGN KEY(IdTemp) REFERENCES Visiteur(IdTemp)
);

-- Création de la table acheter -- testé et c'est bon
CREATE TABLE Acheter(
   NumPermis VARCHAR(50),
   IdCadeau INT,
   PRIMARY KEY(NumPermis, IdCadeau),
   FOREIGN KEY(NumPermis) REFERENCES Conducteur(NumPermis),
   FOREIGN KEY(IdCadeau) REFERENCES Boutique(IdCadeau)
);

-- Création de la table Contient -- testé et c'est bon
CREATE TABLE Contient(
   IdTrajet INT,
   IdLieu VARCHAR(50),
   PRIMARY KEY(IdTrajet, IdLieu),
   FOREIGN KEY(IdTrajet) REFERENCES Trajet(IdTrajet),
   FOREIGN KEY(IdLieu) REFERENCES Escale(IdLieu)
);

-- Création de la table Consulter -- testé et c'est bon
CREATE TABLE Consulter(
   NumPermis VARCHAR(50),
   IdCadeau INT,
   PRIMARY KEY(NumPermis, IdCadeau),
   FOREIGN KEY(NumPermis) REFERENCES Conducteur(NumPermis),
   FOREIGN KEY(IdCadeau) REFERENCES Boutique(IdCadeau)
);

-- Création de la table CommenterPassager -- testé et c'est bon
CREATE TABLE CommenterPassager(
   IdRes INT,
   NumPermis VARCHAR(50),
   CommentaireConducteur TEXT,
   NoteReservation INT,
   PRIMARY KEY(IdRes, NumPermis),
   FOREIGN KEY(IdRes) REFERENCES Reservation(IdRes),
   FOREIGN KEY(NumPermis) REFERENCES Conducteur(NumPermis)
);

-- Création de la table Voir -- testé et c'est bon
CREATE TABLE Voir(
   IdUtilisateur INT,
   IdHistorique INT,
   PRIMARY KEY(IdUtilisateur, IdHistorique),
   FOREIGN KEY(IdUtilisateur) REFERENCES Utilisateur(IdUtilisateur),
   FOREIGN KEY(IdHistorique) REFERENCES Historique(IdHistorique)
);


