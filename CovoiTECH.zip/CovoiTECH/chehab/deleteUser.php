<?php
// Include the database connection file
require_once 'classes/Database.php';

$database = new Database();
$conn = $database->getConnection();
$response = ['success' => false];

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
    $id = $_POST['id'];

    try {
        // Begin transaction
        $conn->beginTransaction();

        // Fetch all NumPermis for the user
        $query = "SELECT NumPermis FROM Conducteur WHERE IdUtilisateur = ?";
        $stmt = $conn->prepare($query);
        $stmt->execute([$id]);
        $numPermisArray = $stmt->fetchAll(PDO::FETCH_COLUMN);

        // Fetch all Matricule for the user's NumPermis
        $matriculeArray = [];
        foreach ($numPermisArray as $numPermis) {
            $query = "SELECT Matricule FROM Voiture WHERE NumPermis = ?";
            $stmt = $conn->prepare($query);
            $stmt->execute([$numPermis]);
            $matricules = $stmt->fetchAll(PDO::FETCH_COLUMN);
            $matriculeArray = array_merge($matriculeArray, $matricules);
        }

        // Fetch all IdTrajet for the user's Matricule
        $idTrajetArray = [];
        foreach ($matriculeArray as $matricule) {
            $query = "SELECT IdTrajet FROM Trajet WHERE Matricule = ?";
            $stmt = $conn->prepare($query);
            $stmt->execute([$matricule]);
            $idTrajets = $stmt->fetchAll(PDO::FETCH_COLUMN);
            $idTrajetArray = array_merge($idTrajetArray, $idTrajets);
        }

        // Fetch all IdRes for the user's IdTrajet
        $idResArray = [];
        foreach ($idTrajetArray as $idTrajet) {
            $query = "SELECT IdRes FROM Reservation WHERE IdTrajet = ?";
            $stmt = $conn->prepare($query);
            $stmt->execute([$idTrajet]);
            $idRes = $stmt->fetchAll(PDO::FETCH_COLUMN);
            $idResArray = array_merge($idResArray, $idRes);
        }

        // Delete from Départ table
        foreach ($idTrajetArray as $idTrajet) {
            $query = "DELETE FROM Départ WHERE IdTrajet = ?";
            $stmt = $conn->prepare($query);
            if (!$stmt->execute([$idTrajet])) {
                throw new Exception("Error deleting from Départ: " . implode(" ", $stmt->errorInfo()));
            }
        }

        // Delete from Reserver table
        foreach ($idResArray as $idRes) {
            $query = "DELETE FROM Reserver WHERE IdRes = ?";
            $stmt = $conn->prepare($query);
            if (!$stmt->execute([$idRes])) {
                throw new Exception("Error deleting from Reserver: " . implode(" ", $stmt->errorInfo()));
            }
        }

        // Delete from CommenterReservation table
        foreach ($idResArray as $idRes) {
            $query = "DELETE FROM CommenterReservation WHERE IdRes = ?";
            $stmt = $conn->prepare($query);
            if (!$stmt->execute([$idRes])) {
                throw new Exception("Error deleting from CommenterReservation: " . implode(" ", $stmt->errorInfo()));
            }
        }

        // Delete from Reservation table
        foreach ($idTrajetArray as $idTrajet) {
            $query = "DELETE FROM Reservation WHERE IdTrajet = ?";
            $stmt = $conn->prepare($query);
            if (!$stmt->execute([$idTrajet])) {
                throw new Exception("Error deleting from Reservation: " . implode(" ", $stmt->errorInfo()));
            }
        }

        // Delete from Trajet table
        foreach ($matriculeArray as $matricule) {
            $query = "DELETE FROM Trajet WHERE Matricule = ?";
            $stmt = $conn->prepare($query);
            if (!$stmt->execute([$matricule])) {
                throw new Exception("Error deleting from Trajet: " . implode(" ", $stmt->errorInfo()));
            }
        }

        // Delete from Voiture table
        foreach ($matriculeArray as $matricule) {
            $query = "DELETE FROM Voiture WHERE Matricule = ?";
            $stmt = $conn->prepare($query);
            if (!$stmt->execute([$matricule])) {
                throw new Exception("Error deleting from Voiture: " . implode(" ", $stmt->errorInfo()));
            }
        }

        // Delete from Conducteur table
        $query = "DELETE FROM Conducteur WHERE IdUtilisateur = ?";
        $stmt = $conn->prepare($query);
        if (!$stmt->execute([$id])) {
            throw new Exception("Error deleting from Conducteur: " . implode(" ", $stmt->errorInfo()));
        }

        // Delete from other related tables that reference Utilisateur
        $relatedTables = [
            'Envoyer' => 'IdUtilisateur',
            'Recevoir' => 'IdUtilisateur',
            'Supprimer' => 'IdUtilisateur',
            'Reserver' => 'IdUtilisateur',
            'AnnulerR' => 'IdUtilisateur',
            'Rechercher' => 'IdUtilisateur',
            'CommenterReservation' => 'IdUtilisateur',
            'MettreJour' => 'IdUtilisateur_initial',
            'MettreJour' => 'IdUtilisateur_actualisé',
            'Interdire' => 'IdAdm',  
            'SeConnecter' => 'IdUtilisateur',
            'Voir' => 'IdUtilisateur'
        ];

        foreach ($relatedTables as $table => $column) {
            $query = "DELETE FROM $table WHERE $column = ?";
            $stmt = $conn->prepare($query);
            if (!$stmt->execute([$id])) {
                throw new Exception("Error deleting from $table: " . implode(" ", $stmt->errorInfo()));
            }
        }

        // Finally, delete from Utilisateur
        $query = "DELETE FROM Utilisateur WHERE IdUtilisateur = ?";
        $stmt = $conn->prepare($query);
        if (!$stmt->execute([$id])) {
            throw new Exception("Error deleting from Utilisateur: " . implode(" ", $stmt->errorInfo()));
        }

        // Commit transaction
        $conn->commit();
        $response['success'] = true;
        $response['message'] = 'Utilisateur supprimé avec succès';
    } catch (Exception $e) {
        // Rollback transaction in case of error
        $conn->rollBack();
        $response['message'] = "Erreur lors de la suppression de l'utilisateur: " . $e->getMessage();
    }
}

echo json_encode($response);
?>
