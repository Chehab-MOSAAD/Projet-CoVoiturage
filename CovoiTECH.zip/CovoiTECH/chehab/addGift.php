<?php
require_once 'classes/Database.php';

$database = new Database();
$conn = $database->getConnection();

$response = ['status' => 'error', 'message' => 'Invalid request'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nomCadeau = $_POST['nomCadeau'];
    $descriptionCadeau = $_POST['descriptionCadeau'];
    $pointsNecessaires = $_POST['pointsNecessaires'];

    try {
        $query = "INSERT INTO Boutique (NomCadeau, DescriptionCadeau, PointsNecessaires) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($query);
        if ($stmt->execute([$nomCadeau, $descriptionCadeau, $pointsNecessaires])) {
            $response['status'] = 'success';
            $response['message'] = 'Cadeau ajouté avec succès';
        } else {
            $response['message'] = 'Failed to insert data';
        }
    } catch (PDOException $e) {
        $response['message'] = 'Database query error: ' . $e->getMessage();
    }
} else {
    $response['message'] = 'Invalid request method';
}

header('Content-Type: application/json');
echo json_encode($response);
?>
