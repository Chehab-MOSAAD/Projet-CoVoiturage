<?php
class Database {
    private $host = "localhost";
    private $db_name = "BD_CovoiTECH"; 
    private $username = "postgres"; 
    private $password = "13102002"; 
    private $port = "5432";
    private $conn;

    public function getConnection() {
        $this->conn = null;
        try {
            // Change the DSN for PostgreSQL
            $dsn = "pgsql:host=$this->host;port=$this->port;dbname=$this->db_name;user=$this->username;password=$this->password";
            $this->conn = new PDO($dsn);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $exception) {
            die("Connection error: " . $exception->getMessage());
        }
        return $this->conn;
    }

       // Method to execute a query and return the result
       public function runQuery($sql) {
        if ($this->conn === null) {
            $this->getConnection(); // Ensure connection is active
        }
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        return $stmt;
    }
}

?>
