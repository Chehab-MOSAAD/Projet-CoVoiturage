<?php
require_once 'classes/Database.php';

$database = new Database();
$conn = $database->getConnection();
$response = ['success' => false];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    error_log("Received POST request"); // Check server logs to confirm this is received
    if (empty($_POST['id'])) {
        error_log("ID is missing");
        die(json_encode(['success' => false, 'message' => 'ID parameter is missing']));
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
    $id = $_POST['id'];
    $mail = $_POST['mail'];
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];

    $stmt = $conn->prepare("UPDATE Utilisateur SET Mail = ?, Nom = ?, Prenom = ? WHERE IdUtilisateur = ?");
    if ($stmt->execute([$mail, $nom, $prenom, $id])) {
        $response = ['success' => true, 'message' => 'User updated successfully'];
    } else {
        $response = ['success' => false, 'message' => 'Error updating user'];
    }
}

echo json_encode($response);