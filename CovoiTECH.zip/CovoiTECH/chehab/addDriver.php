<?php
// Include the database connection file
require_once 'classes/Database.php';

$database = new Database();
$conn = $database->getConnection();
$response = ['success' => false];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $idUtilisateur = $_POST['idutilisateur'];
    $numPermis = $_POST['numPermis'];
    $points = $_POST['points'];
    $noteConducteur = $_POST['noteConducteur'];
    $matricule = $_POST['matricule'];
    $marque = $_POST['marque'];
    $modele = $_POST['modele'];
    $type = $_POST['type'];
    $couleur = $_POST['couleur'];
    $nbrPlace = $_POST['nbrPlace'];
    $carburant = $_POST['carburant'];

    try {
        // Begin transaction
        $conn->beginTransaction();

        // Insert into Conducteur table
        $query = "INSERT INTO Conducteur (NumPermis, Points, NoteConducteur, IdUtilisateur) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        if (!$stmt->execute([$numPermis, $points, $noteConducteur, $idUtilisateur])) {
            throw new Exception("Error inserting into Conducteur: " . implode(" ", $stmt->errorInfo()));
        }

        // Insert into Voiture table
        $query = "INSERT INTO Voiture (Matricule, Marque, Modele, Type, Couleur, NbrPlace, Carburant, NumPermis) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        if (!$stmt->execute([$matricule, $marque, $modele, $type, $couleur, $nbrPlace, $carburant, $numPermis])) {
            throw new Exception("Error inserting into Voiture: " . implode(" ", $stmt->errorInfo()));
        }

        // Commit transaction
        $conn->commit();
        $response['success'] = true;
        $response['message'] = 'Conducteur ajouté avec succès';
    } catch (Exception $e) {
        // Rollback transaction in case of error
        $conn->rollBack();
        $response['message'] = "Erreur lors de l'ajout du conducteur: " . $e->getMessage();
    }
}

echo json_encode($response);
?>
