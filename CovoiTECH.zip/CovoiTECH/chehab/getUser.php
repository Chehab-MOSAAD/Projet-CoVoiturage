<?php
require_once 'classes/Database.php';

$database = new Database();
$conn = $database->getConnection();
$response = ['success' => false];

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    $id = $_GET['id'];

    $stmt = $conn->prepare("SELECT * FROM Utilisateur WHERE IdUtilisateur = ?");
    $stmt->execute([$id]);

    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        error_log("Fetched user data: " . json_encode($row)); // Debug message
        $response = ['success' => true, 'data' => $row];
    } else {
        error_log("User not found for ID: $id"); // Debug message
        $response = ['success' => false, 'message' => 'User not found'];
    }
} else {
    error_log("Invalid request method or missing ID parameter"); // Debug message
}

echo json_encode($response);
?>
