<?php
require_once 'classes/Database.php';

$database = new Database();
$conn = $database->getConnection();

// Prepare SQL statement to fetch all necessary user data
$sql = "SELECT IdUtilisateur, Mail, Nom, Prenom FROM Utilisateur";
$stmt = $conn->prepare($sql);
$stmt->execute();

?>

<!doctype html>
<html class="no-js" lang="zxx">
    <head>
        <!-- Meta Tags -->
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="keywords" content="Site keywords here">
		<meta name="description" content="">
		<meta name='copyright' content=''>
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		
		<!-- Title -->
        <title>Projet BD-PHP-WEB Plateforme Co-Voiturage : Table Utilisateur</title>
		
		<!-- Favicon -->
        <link rel="icon" href="images/favicon.png">
		
		<!-- Google Fonts -->
		<link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<!-- Nice Select CSS -->
		<link rel="stylesheet" href="css/nice-select.css">
		<!-- Font Awesome CSS -->
        <link rel="stylesheet" href="css/font-awesome.min.css">
		<!-- icofont CSS -->
        <link rel="stylesheet" href="css/icofont.css">
		<!-- Slicknav -->
		<link rel="stylesheet" href="css/slicknav.min.css">
		<!-- Owl Carousel CSS -->
        <link rel="stylesheet" href="css/owl-carousel.css">
		<!-- Datepicker CSS -->
		<link rel="stylesheet" href="css/datepicker.css">
		<!-- Animate CSS -->
        <link rel="stylesheet" href="css/animate.min.css">
		<!-- Magnific Popup CSS -->
        <link rel="stylesheet" href="css/magnific-popup.css">
		
		<!-- Medipro CSS -->
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="css/responsive.css">
		
		<!-- Include in the <head> section -->
		<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
		<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

		<!-- Include Bootstrap JS and Popper.js at the end of your document -->
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    </head>
    <body>
	
		<!-- Preloader -->
        <div class="preloader">
            <div class="loader">
                <div class="loader-outter"></div>
                <div class="loader-inner"></div>

                <div class="indicator"> 
                    <svg width="16px" height="12px">
                        <polyline id="back" points="1 6 4 6 6 11 10 1 12 6 15 6"></polyline>
                        <polyline id="front" points="1 6 4 6 6 11 10 1 12 6 15 6"></polyline>
                    </svg>
                </div>
            </div>
        </div>
        <!-- End Preloader -->
	
		<!-- Header Area -->
		<header class="header" >
			<!-- Header Inner -->
			<div class="header-inner">
				<div class="container">
					<div class="inner">
						<div class="row">
							<div class="col-lg-3 col-md-3 col-12">
								<!-- Start Logo -->
								<div class="logo">
									<a href="Admin_index.php"><img src="images/logo.png" alt="#"></a>
								</div>
								<!-- End Logo -->
								<!-- Mobile Nav -->
								<div class="mobile-nav"></div>
								<!-- End Mobile Nav -->
							</div>
							<div class="col-lg-7 col-md-9 col-12">
								<!-- Main Menu -->
								<div class="main-menu">
									<nav class="navigation">
										<ul class="nav menu">
											<li><a href="Admin_index.php">Accueil</a></li>
											<li><a href="..\Linda\admin_requests.php">Alertes</a></li>
											<li><a href="..\Linda\contacts.php">Messagrie</a></li>
											<li><a href="" class="typewrite" data-period="2000" data-type='[ "Bienvenue chez CovoiTECH", "Votre trajet, notre priorité", "Ensemble sur la route !" ]'></a></li>
										</ul>
									</nav>
								</div>
								<!--/ End Main Menu -->
							</div>
							<div class="col-lg-1 col-12">
								<div class="get-quote">
									<a href="Visiteur_index.html" class="btn">Déconnexion</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--/ End Header Inner -->
		</header>
		<div class="container">
			<h3>Les utilisateurs</h3>
			<table class="table">
				<thead>
					<tr>
						<th>ID</th>
						<th>Mail</th>
						<th>Nom</th>
						<th>Prénom</th>
						<th>Sexe</th>
						<th>Tel</th>
						<th>Handicap</th>
						<th>Note Passager</th>
						<th>Langue Parlée 1</th>
						<th>Langue Parlée 2</th>
						<th>Fumeur</th>
						<th>Date de Naissance</th>
						<th>Est Conducteur</th>
						<th>Actions</th>
					</tr>
				</thead>
				<tbody>
					<?php
					require_once 'classes/Database.php';

					$database = new Database();
					$conn = $database->getConnection();

					$sql = "
						SELECT 
							u.IdUtilisateur, 
							u.Mail, 
							u.Nom, 
							u.Prenom, 
							u.Sexe, 
							u.Tel, 
							u.Handicap, 
							u.NotePassager, 
							u.LangueParle1, 
							u.LangueParle2, 
							u.Fumeur, 
							u.Jour, 
							u.Mois, 
							u.Annee,
							CASE WHEN c.IdUtilisateur IS NOT NULL THEN TRUE ELSE FALSE END AS EstConducteur
						FROM Utilisateur u
						LEFT JOIN Conducteur c ON u.IdUtilisateur = c.IdUtilisateur";
					$stmt = $conn->prepare($sql);
					$stmt->execute();

					while ($row = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
						<tr>
							<td><?= htmlspecialchars($row['idutilisateur']) ?></td>
							<td><?= htmlspecialchars($row['mail']) ?></td>
							<td><?= htmlspecialchars($row['nom']) ?></td>
							<td><?= htmlspecialchars($row['prenom']) ?></td>
							<td><?= htmlspecialchars($row['sexe']) ?></td>
							<td><?= htmlspecialchars($row['tel']) ?></td>
							<td><?= htmlspecialchars($row['handicap'] ? 'Oui' : 'Non') ?></td>
							<td><?= htmlspecialchars($row['notepassager']) ?></td>
							<td><?= htmlspecialchars($row['langueparle1']) ?></td>
							<td><?= htmlspecialchars($row['langueparle2']) ?></td>
							<td><?= htmlspecialchars($row['fumeur'] ? 'Oui' : 'Non') ?></td>
							<td><?= htmlspecialchars($row['jour'] . '/' . $row['mois'] . '/' . $row['annee']) ?></td>
							<td><?= htmlspecialchars($row['estconducteur'] ? 'Oui' : 'Non') ?></td>
							<td>
								<button onclick="editUser('<?= htmlspecialchars($row['idutilisateur']) ?>')" class="btn btn-primary">Modifier</button>
								<button onclick="deleteUser('<?= htmlspecialchars($row['idutilisateur']) ?>')" class="btn btn-danger">Supprimer</button>
								<?php if (!$row['estconducteur']): ?>
									<button onclick="showDriverModal('<?= htmlspecialchars($row['idutilisateur']) ?>')" class="btn btn-success">Être Conducteur</button>
								<?php endif; ?>
							</td>
						</tr>
					<?php endwhile; ?>
				</tbody>
			</table>

			<!-- Modal -->
			<div class="modal fade" id="editUserModal" tabindex="-1" role="dialog" aria-labelledby="editUserModalLabel" aria-hidden="true">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="editUserModalLabel">Modifier Utilisateur</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form id="editUserForm">
						<input type="hidden" id="userId" name="id">
						<div class="form-group">
							<label for="mail">Mail:</label>
							<input type="email" class="form-control" id="mail" name="mail">
						</div>
						<div class="form-group">
							<label for="nom">Nom:</label>
							<input type="text" class="form-control" id="nom" name="nom">
						</div>
						<div class="form-group">
							<label for="prenom">Prénom:</label>
							<input type="text" class="form-control" id="prenom" name="prenom">
						</div>
					</form>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
					<button type="button" class="btn btn-primary" onclick="updateUser()">Mettre à jour</button>
				</div>
				</div>
			</div>
			</div>

			<!-- Modal for Adding Driver -->
			<div class="modal fade" id="driverModal" tabindex="-1" role="dialog" aria-labelledby="driverModalLabel" aria-hidden="true">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="driverModalLabel">Ajouter Conducteur</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<div class="modal-body">
							<form id="driverForm">
								<input type="hidden" id="driverUserId" name="idutilisateur">
								
								<!-- Driver Information -->
								<div class="form-group">
									<label for="numPermis">Numéro de Permis</label>
									<input type="text" class="form-control" id="numPermis" name="numPermis" required>
								</div>
								<div class="form-group">
									<label for="points">Points</label>
									<input type="number" class="form-control" id="points" name="points" min="0" max="15" required>
								</div>
								<div class="form-group">
									<label for="noteConducteur">Note Conducteur</label>
									<input type="number" class="form-control" id="noteConducteur" name="noteConducteur" step="0.1" min="0" max="5">
								</div>
								
								<!-- Car Information -->
								<div class="form-group">
									<label for="matricule">Matricule</label>
									<input type="text" class="form-control" id="matricule" name="matricule" required>
								</div>
								<div class="form-group">
									<label for="marque">Marque</label>
									<input type="text" class="form-control" id="marque" name="marque" required>
								</div>
								<div class="form-group">
									<label for="modele">Modèle</label>
									<input type="text" class="form-control" id="modele" name="modele" required>
								</div>
								<div class="form-group">
									<label for="type">Type</label>
									<select class="form-control" id="type" name="type" required>
										<option value="SUV">SUV</option>
										<option value="Berline">Berline</option>
										<option value="Compacte">Compacte</option>
										<option value="Monospace">Monospace</option>
									</select>
								</div>
								<div class="form-group">
									<label for="couleur">Couleur</label>
									<select class="form-control" id="couleur" name="couleur" required>
										<option value="bleu">Bleu</option>
										<option value="violet">Violet</option>
										<option value="rose">Rose</option>
										<option value="rouge">Rouge</option>
										<option value="orange">Orange</option>
										<option value="jaune">Jaune</option>
										<option value="vert">Vert</option>
										<option value="noir">Noir</option>
										<option value="marron">Marron</option>
										<option value="gris">Gris</option>
										<option value="aluminium">Aluminium</option>
										<option value="argent">Argent</option>
										<option value="blanc">Blanc</option>
									</select>
								</div>
								<div class="form-group">
									<label for="nbrPlace">Nombre de Places</label>
									<input type="number" class="form-control" id="nbrPlace" name="nbrPlace" min="1" max="100" required>
								</div>
								<div class="form-group">
									<label for="carburant">Carburant</label>
									<select class="form-control" id="carburant" name="carburant" required>
										<option value="essence">Essence</option>
										<option value="diesel">Diesel</option>
										<option value="éthanol">Éthanol</option>
										<option value="gaz">Gaz</option>
										<option value="électrique">Électrique</option>
										<option value="hybride">Hybride</option>
									</select>
								</div>
								
								<button type="button" class="btn btn-primary" onclick="addDriver()">Ajouter</button>
							</form>
						</div>
					</div>
				</div>
			</div>

		</div>

		<script>
		function editUser(id) {
			$.ajax({
				url: 'getUser.php',
				type: 'GET',
				data: { id: id },
				success: function(response) {
					const data = JSON.parse(response);
					if (data.success) {
						$('#userId').val(data.data.idutilisateur);
						$('#mail').val(data.data.mail);
						$('#nom').val(data.data.nom);
						$('#prenom').val(data.data.prenom);
						$('#editUserModal').modal('show');
					} else {
						alert('Unable to fetch user data');
					}
				},
				error: function() {
					alert('Error fetching data');
				}
			});
		}


		function updateUser() {
			var id = $('#userId').val();
			var mail = $('#mail').val();
			var nom = $('#nom').val();
			var prenom = $('#prenom').val();

			if (!id) {
				alert('User ID is missing!');
				return; // Stop the function if no ID is present
			}

			$.ajax({
				url: 'updateUser.php',
				type: 'POST',
				data: {
					id: id,
					mail: mail,
					nom: nom,
					prenom: prenom
				},
				success: function(response) {
					var data = JSON.parse(response);
					if (data.success) {
						$('#editUserModal').modal('hide');
						alert('User updated successfully');
						location.reload(); // Refresh the page to update the list
					} else {
						alert('Update failed: ' + data.message);
					}
				},
				error: function() {
					alert('Error updating data');
				}
			});
		}

		function deleteUser(id) {
			if (confirm("Êtes-vous sûr de vouloir supprimer cet utilisateur?")) {
				$.ajax({
					url: 'deleteUser.php',
					type: 'POST',
					data: { id: id },
					success: function(response) {
						var data = JSON.parse(response);
						if (data.success) {
							alert('Utilisateur supprimé avec succès');
							location.reload(); // Refresh the page to show the updated list
						} else {
							alert('Échec de la suppression: ' + data.message);
						}
					},
					error: function() {
						alert('Erreur lors de la suppression de l’utilisateur');
					}
				});
			}
		}


		function showDriverModal(userId) {
			$('#driverUserId').val(userId);
			$('#driverModal').modal('show');
		}

		function addDriver() {
			var formData = $('#driverForm').serialize();

			$.ajax({
				url: 'addDriver.php',
				type: 'POST',
				data: formData,
				success: function(response) {
					var result = JSON.parse(response);
					if (result.success) {
						alert('Conducteur ajouté avec succès');
						location.reload(); // Reload the page to reflect changes
					} else {
						alert('Erreur lors de l\'ajout du conducteur: ' + result.message);
					}
				},
				error: function() {
					alert('Erreur lors de l\'ajout du conducteur. Veuillez réessayer.');
				}
			});
		}

		</script>

		<!-- Footer Area -->
		<footer id="footer" class="footer ">
			<div class="footer-top">
				<div class="container">
					<div class="row">
						<div class="col-lg-9 col-md-6 col-12">
							<div class="single-footer">
								<h2>À propos</h2>
								<p>Notre site simule une plateforme intuitive où les utilisateurs peuvent proposer ou rechercher des trajets, gérer leurs réservations et interagir avec d’autres membres. L’accent a été mis sur la simplicité d’utilisation, la sécurité des données et la  Création d’une expérience utilisateur engageante. </p>
								<p><br>Ce site web de covoiturage est le fruit d’un projet académique mené par un groupe d'étudiants de l’UPSSITECH, développé en PHP, HTML, CSS, Javascript et appuyé par une base de données robuste. Il sert principalement de démonstration des compétences techniques acquises durant notre année universitaire et n’est pas destiné à un usage commercial.</p>
							</div>
						</div>
						<div class="col-lg-3 col-md-6 col-12">
							<div class="single-footer f-link">
								<h2>Membres de l’équipe</h2>
								<p>-> Chehab MOSAAD
									<br>-> Nizar SLAMA SEFI
									<br>-> Miniar JABRI
									<br>-> Lina AHNOUDJ 
									<br>-> Linda BEDOUI
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
		<!--/ End Footer Area -->
		
		<!-- jquery Min JS -->
        <script src="js/jquery.min.js"></script>
		<!-- jquery Migrate JS -->
		<script src="js/jquery-migrate-3.0.0.js"></script>
		<!-- jquery Ui JS -->
		<script src="js/jquery-ui.min.js"></script>
		<!-- Easing JS -->
        <script src="js/easing.js"></script>
		<!-- Color JS -->
		<script src="js/colors.js"></script>
		<!-- Popper JS -->
		<script src="js/popper.min.js"></script>
		<!-- Bootstrap Datepicker JS -->
		<script src="js/bootstrap-datepicker.js"></script>
		<!-- Jquery Nav JS -->
        <script src="js/jquery.nav.js"></script>
		<!-- Slicknav JS -->
		<script src="js/slicknav.min.js"></script>
		<!-- ScrollUp JS -->
        <script src="js/jquery.scrollUp.min.js"></script>
		<!-- Niceselect JS -->
		<script src="js/niceselect.js"></script>
		<!-- Tilt Jquery JS -->
		<script src="js/tilt.jquery.min.js"></script>
		<!-- Owl Carousel JS -->
        <script src="js/owl-carousel.js"></script>
		<!-- counterup JS -->
		<script src="js/jquery.counterup.min.js"></script>
		<!-- Steller JS -->
		<script src="js/steller.js"></script>
		<!-- Wow JS -->
		<script src="js/wow.min.js"></script>
		<!-- Magnific Popup JS -->
		<script src="js/jquery.magnific-popup.min.js"></script>
		<!-- Counter Up CDN JS -->
		<script src="http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>
		<!-- Bootstrap JS -->
		<script src="js/bootstrap.min.js"></script>
		<!-- Main JS -->
		<script src="js/main.js"></script>
    </body>
</html>