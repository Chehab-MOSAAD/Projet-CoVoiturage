
<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['driver_info'])) {
    header("Location: connexion_conducteur.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['idTrajet']) && isset($_POST['commentaire'])) {
    $idTrajet = $_POST['idTrajet'];
    $commentaire = $_POST['commentaire'];

    $query = "UPDATE Trajet SET CommentaireTrajetConducteur = $1 WHERE IdTrajet = $2";
    $result = pg_query_params($db, $query, array($commentaire, $idTrajet));

    if ($result) {
        $_SESSION['message'] = 'Commentaire ajouté avec succès.';
    } else {
        $_SESSION['message'] = 'Erreur lors de l\'ajout du commentaire.';
    }
    header("Location: historique_conducteur.php");
    exit;
}

$numPermis = $_SESSION['driver_info']['numpermis'] ?? null;
if (!$numPermis) {
    echo "État de session invalide.";
    exit;
}

$sql = "SELECT t.IdTrajet, t.VilleDepart, t.VilleArrivee, r.ReservationStatus, 
               u.IdUtilisateur, u.Mail, u.Nom, u.Prenom, u.Sexe, u.Tel, u.Handicap, 
               u.NotePassager, u.LangueParle1, u.LangueParle2, u.Fumeur,
               d.JourDepart, d.JourArrivee, d.HeureDepart, d.HeureArrivee,
               r.IdRes, t.CommentaireTrajetConducteur
        FROM Trajet t
        JOIN Reservation r ON t.IdTrajet = r.IdTrajet
        JOIN Reserver rs ON r.IdRes = rs.IdRes
        JOIN Utilisateur u ON rs.IdUtilisateur = u.IdUtilisateur
        JOIN Départ d ON t.IdTrajet = d.IdTrajet
        WHERE t.NumPermis = $1
        ORDER BY r.ReservationStatus DESC, t.IdTrajet ASC";

$result = pg_query_params($db, $sql, array($numPermis));
if (!$result) {
    echo "Erreur de requête SQL.";
    exit;
}

$trajets = pg_fetch_all($result) ?: [];

$trajetsConfirmes = [];
$trajetsNonConfirmes = [];

foreach ($trajets as $trajet) {
    if ($trajet['reservationstatus'] === 'Confirmed') {
        $trajetsConfirmes[] = $trajet;
    } else {
        $trajetsNonConfirmes[] = $trajet;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="Site keywords here">
    <meta name="description" content="">
    <meta name='copyright' content=''>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title -->
    <title>Historique- CovoiTECH</title>

    <!-- Favicon -->
    <link rel="icon" href="images/favicon.png">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Nice Select CSS -->
    <link rel="stylesheet" href="css/nice-select.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!-- icofont CSS -->
    <link rel="stylesheet" href="css/icofont.css">
    <!-- Slicknav -->
    <link rel="stylesheet" href="css/slicknav.min.css">
    <!-- Owl Carousel CSS -->
    <link rel="stylesheet" href="css/owl-carousel.css">
    <!-- Datepicker CSS -->
    <link rel="stylesheet" href="css/datepicker.css">
    <!-- Animate CSS -->
    <link rel="stylesheet" href="css/animate.min.css">
    <!-- Magnific Popup CSS -->
    <link rel="stylesheet" href="css/magnific-popup.css">

    <!-- Medipro CSS -->
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/responsive.css">

    <style>
        /* Style global */
        header {
            padding: 1em 0;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
            width: 100%;
            position: fixed;
            top: 0;
            z-index: 100;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        nav a {
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            font-weight: bold;
        }

        nav a:hover, nav a.active {
            background-color: #4c894e;
        }

        /* Style du contenu principal */
        .content {
            transition: margin-left 0.3s;
            padding: 20px;
            margin-top: 80px;
        }

        .card {
            background-color: white;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
            transition: transform 0.3s;
        }

        .card:hover {
            transform: scale(1.03);
        }

        @media screen and (max-width: 768px) {
            .content {
                margin-left: 0;
            }
        }

        #results-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            list-style: none;
            padding: 0;
        }

        .search-result {
            background-color: #fff;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        }

        .search-result:hover {
            transform: translateY(-5px);
        }

        .search-result .info {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }

        h2 {
            color: #333;
            margin-bottom: 15px;
        }

        p {
            color: #555;
            margin: 5px 0;
        }

        button {
            background-color: #63a35c;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 10px 15px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #4c894e;
        }

    </style>
</head>
<body>

    <!-- Preloader -->
    <div class="preloader">
        <div class="loader">
            <div class="loader-outter"></div>
            <div class="loader-inner"></div>

            <div class="indicator"> 
                <svg width="16px" height="12px">
                    <polyline id="back" points="1 6 4 6 6 11 10 1 12 6 15 6"></polyline>
                    <polyline id="front" points="1 6 4 6 6 11 10 1 12 6 15 6"></polyline>
                </svg>
            </div>
        </div>
    </div>
    <!-- End Preloader -->

    <!-- Header Area -->
    <header class="header">
        <!-- Header Inner -->
        <div class="header-inner">
            <div class="container">
                <div class="inner">
                    <div class="row">
                        <div class="col-lg-3 col-md-3 col-12">
                            <!-- Start Logo -->
                            <div class="logo">
                                <a href="/../CovoiTECH/chehab/Utilisateur_index.html"><img src="images/logo.png" alt="#"></a>
                            </div>
                            <!-- End Logo -->
                            <!-- Mobile Nav -->
                            <div class="mobile-nav"></div>
                            <!-- End Mobile Nav -->
                        </div>
                        <div class="col-lg-7 col-md-9 col-12">
                            <!-- Main Menu -->
                            <div class="main-menu">
                                <nav class="navigation">
                                    <ul class="nav menu">
                                        <li><a href="/../CovoiTECH/chehab/Utilisateur_index.html">Accueil</a></li>
                                        <li><a href="/../CovoiTECH/Linda/contacts.php">Messagerie</a></li>
                                        <li><a href="mettre_a_jours.php">Mettre à jour</a></li>
                                        <li><a href="" class="typewrite" data-period="2000" data-type='[ "Bienvenue chez CovoiTECH", "Votre trajet, notre priorité", "Ensemble sur la route !" ]'></a></li>
                                    </ul>
                                </nav>
                            </div>
                            <!--/ End Main Menu -->
                        </div>
                        <div class="col-lg-1 col-12">
                            <div class="get-quote">
                                <a href="deconnexion.php" class="btn">Déconnexion</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/ End Header Inner -->
    </header>
    <!-- end section -->

    <div class="container">
        <div class="content">
            <?php if (isset($_SESSION['message'])): ?>
                <div class="alert alert-info">
                    <?= $_SESSION['message']; ?>
                    <?php unset($_SESSION['message']); ?>
                </div>
            <?php endif; ?>

            <h3 style="text-align: center; margin-top: 30px;">Trajets Confirmés</h3>
            <div class="list-group">
                <?php if (!empty($trajetsConfirmes)): ?>
                    <?php foreach ($trajetsConfirmes as $trajet): ?>
                        <div class="card">
                        <p>De: <?= htmlspecialchars($trajet['villedepart']) ?></p>
                        <p>À: <?= htmlspecialchars($trajet['villearrivee']) ?></p>
                        <p>Passager ID: <?= htmlspecialchars($trajet['idutilisateur']) ?></p>
                        <p>Nom: <?= htmlspecialchars($trajet['nom']) ?> <?= htmlspecialchars($trajet['prenom']) ?></p>
                        <p>Email: <?= htmlspecialchars($trajet['mail']) ?></p>
                        <p>Sexe: <?= htmlspecialchars($trajet['sexe']) ?></p>
                        <p>Téléphone: <?= htmlspecialchars($trajet['tel']) ?></p>
                        <p>Handicap: <?= htmlspecialchars($trajet['handicap'] ? 'Oui' : 'Non') ?></p>
                        <p>Note Passager: <?= htmlspecialchars($trajet['notepassager']) ?></p>
                        <p>Langues Parlées: <?= htmlspecialchars($trajet['langueparle1']) ?>, <?= htmlspecialchars($trajet['langueparle2']) ?></p>
                        <p>Fumeur: <?= htmlspecialchars($trajet['fumeur'] ? 'Oui' : 'Non') ?></p>
                        <p>Date de départ: <?= htmlspecialchars($trajet['jourdepart']) ?></p>
                        <p>Heure de départ: <?= htmlspecialchars($trajet['heuredepart']) ?></p>
                        <p>Date d'arrivée: <?= htmlspecialchars($trajet['jourarrivee']) ?></p>
                        <p>Heure d'arrivée: <?= htmlspecialchars($trajet['heurearrivee']) ?></p>
                            <p><strong>Status:</strong> Confirmé</p>
                            <p><strong>Commentaire Conducteur:</strong> <?= htmlspecialchars($trajet['commentairetrajetconducteur']) ?></p>
                            <form method="post" action="">
                                <input type="hidden" name="idTrajet" value="<?= htmlspecialchars($trajet['idtrajet']) ?>">
                                <input type="text" name="commentaire" placeholder="Ajouter un commentaire" required>
                                <button type="submit">Commenter</button>
                            </form>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p style="text-align: center;">Aucun trajet confirmé trouvé.</p>
                <?php endif; ?>
            </div>

            <h3 style="text-align: center;">Trajets Non Confirmés</h3>
            <div class="list-group">
                <?php if (!empty($trajetsNonConfirmes)): ?>
                    <?php foreach ($trajetsNonConfirmes as $trajet): ?>
                        <div class="card">
                        <p>De: <?= htmlspecialchars($trajet['villedepart']) ?></p>
                        <p>À: <?= htmlspecialchars($trajet['villearrivee']) ?></p>
                        <p>Passager ID: <?= htmlspecialchars($trajet['idutilisateur']) ?></p>
                        <p>Nom: <?= htmlspecialchars($trajet['nom']) ?> <?= htmlspecialchars($trajet['prenom']) ?></p>
                        <p>Email: <?= htmlspecialchars($trajet['mail']) ?></p>
                        <p>Sexe: <?= htmlspecialchars($trajet['sexe']) ?></p>
                        <p>Téléphone: <?= htmlspecialchars($trajet['tel']) ?></p>
                        <p>Handicap: <?= htmlspecialchars($trajet['handicap'] ? 'Oui' : 'Non') ?></p>
                        <p>Note Passager: <?= htmlspecialchars($trajet['notepassager']) ?></p>
                        <p>Langues Parlées: <?= htmlspecialchars($trajet['langueparle1']) ?>, <?= htmlspecialchars($trajet['langueparle2']) ?></p>
                        <p>Fumeur: <?= htmlspecialchars($trajet['fumeur'] ? 'Oui' : 'Non') ?></p>
                        <p>Date de départ: <?= htmlspecialchars($trajet['jourdepart']) ?></p>
                        <p>Heure de départ: <?= htmlspecialchars($trajet['heuredepart']) ?></p>
                        <p>Date d'arrivée: <?= htmlspecialchars($trajet['jourarrivee']) ?></p>
                        <p>Heure d'arrivée: <?= htmlspecialchars($trajet['heurearrivee']) ?></p>
                            <p><strong>Status:</strong> Non confirmé</p>
                            <p><strong>Commentaire Conducteur:</strong> <?= htmlspecialchars($trajet['commentairetrajetconducteur']) ?></p>
                            <form method="post" action="">
                                <input type="hidden" name="idTrajet" value="<?= htmlspecialchars($trajet['idtrajet']) ?>">
                                <input type="text" name="commentaire" placeholder="Ajouter un commentaire" required>
                                <button type="submit">Commenter</button>
                            </form>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p style="text-align: center;">Aucun trajet non confirmé trouvé.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Footer Area -->
    <footer id="footer" class="footer">
        <div class="footer-top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 col-md-6 col-12">
                        <div class="single-footer">
                            <h2>À propos</h2>
                            <p>Notre site simule une plateforme intuitive où les utilisateurs peuvent proposer ou rechercher des trajets, gérer leurs réservations et interagir avec d’autres membres. L’accent a été mis sur la simplicité d’utilisation, la sécurité des données et la création d’une expérience utilisateur engageante.</p>
                            <p><br>Ce site web de covoiturage est le fruit d’un projet académique mené par un groupe d'étudiants de l’UPSSITECH, développé en PHP, HTML, CSS, Javascript et appuyé par une base de données robuste. Il sert principalement de démonstration des compétences techniques acquises durant notre année universitaire et n’est pas destiné à un usage commercial.</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="single-footer f-link">
                            <h2>Membres de l’équipe</h2>
                            <p>-> Chehab MOSAAD
                                <br>-> Nizar SLAMA SEFI
                                <br>-> Miniar JABRI
                                <br>-> Lina AHNOUDJ 
                                <br>-> Linda BEDOUI
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--/ End Footer Area -->

    <!-- jquery Min JS -->
    <script src="js/jquery.min.js"></script>
    <!-- jquery Migrate JS -->
    <script src="js/jquery-migrate-3.0.0.js"></script>
    <!-- jquery Ui JS -->
    <script src="js/jquery-ui.min.js"></script>
    <!-- Easing JS -->
    <script src="js/easing.js"></script>
    <!-- Color JS -->
    <script src="js/colors.js"></script>
    <!-- Popper JS -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap Datepicker JS -->
    <script src="js/bootstrap-datepicker.js"></script>
    <!-- Jquery Nav JS -->
    <script src="js/jquery.nav.js"></script>
    <!-- Slicknav JS -->
    <script src="js/slicknav.min.js"></script>
    <!-- ScrollUp JS -->
    <script src="js/jquery.scrollUp.min.js"></script>
    <!-- Niceselect JS -->
    <script src="js/niceselect.js"></script>
    <!-- Tilt Jquery JS -->
    <script src="js/tilt.jquery.min.js"></script>
    <!-- Owl Carousel JS -->
    <script src="js/owl-carousel.js"></script>
    <!-- counterup JS -->
    <script src="js/jquery.counterup.min.js"></script>
    <!-- Steller JS -->
    <script src="js/steller.js"></script>
    <!-- Wow JS -->
    <script src="js/wow.min.js"></script>
    <!-- Magnific Popup JS -->
    <script src="js/jquery.magnific-popup.min.js"></script>
    <!-- Counter Up CDN JS -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Main JS -->
    <script src="js/main.js"></script>
</body>
</html>
