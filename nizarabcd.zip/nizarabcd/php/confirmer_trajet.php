<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['driver_info'])) {
    header("Location: connexion_conducteur.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['idTrajet'])) {
    $idTrajet = $_POST['idTrajet'];

    $query = "UPDATE Reservation SET ReservationStatus = 'Confirmed' WHERE IdTrajet = $1";
    $result = pg_query_params($db, $query, array($idTrajet));

    if ($result) {
        $_SESSION['message'] = 'Trajet confirmé avec succès.';
    } else {
        $_SESSION['message'] = 'Erreur lors de la confirmation du trajet.';
    }
    header("Location: historique_conducteur.php");
    exit;
}
?>
