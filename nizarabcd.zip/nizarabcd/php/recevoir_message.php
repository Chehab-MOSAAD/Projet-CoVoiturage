<?php
// Inclure le fichier de connexion à la base de données
require 'db.php';

// ID de l'administrateur à qui les messages sont envoyés
$adminId = 3;

// Préparer et exécuter la requête SQL
$query = "SELECT m.IdSession, m.Message, r.Jour, r.Mois, r.Annee
          FROM Messagerie m
          JOIN RecevoirAdmin r ON m.IdSession = r.IdSession
          WHERE r.IdAdm = $1";

$result = pg_query_params($db, $query, [$adminId]);

if (!$result) {
    die("Erreur lors de la récupération des messages: " . pg_last_error($db));
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messages vers Admin ID 3</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f9;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>Messages vers Admin ID 3</h1>
    <table>
        <tr>
            <th>Id Session</th>
            <th>Message</th>
            <th>Jour</th>
            <th>Mois</th>
            <th>Année</th>
        </tr>
        <?php while ($row = pg_fetch_assoc($result)): ?>
        <tr>
            <td><?= htmlspecialchars($row['idsession']) ?></td>
            <td><?= htmlspecialchars($row['message']) ?></td>
            <td><?= htmlspecialchars($row['jour']) ?></td>
            <td><?= htmlspecialchars($row['mois']) ?></td>
            <td><?= htmlspecialchars($row['annee']) ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>

<?php
// Libérer le résultat
pg_free_result($result);

// Fermer la connexion
pg_close($db);
?>
