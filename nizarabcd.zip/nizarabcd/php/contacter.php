<?php
// Connexion à la base de données
require 'db.php';

// Vérification des paramètres GET
if (!isset($_GET['exp_id']) || !isset($_GET['dest_id']) || !isset($_GET['nom']) || !isset($_GET['prenom'])) {
    die("Paramètres manquants.");
}

$exp_id = (int) $_GET['exp_id'];
$dest_id = (int) $_GET['dest_id'];
$nom = htmlspecialchars($_GET['nom']);
$prenom = htmlspecialchars($_GET['prenom']);

// Initialiser le message de retour
$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupération et validation du contenu du message
    $contenu = filter_input(INPUT_POST, 'contenu', FILTER_SANITIZE_STRING);
    if (!$contenu) {
        $message = "Le message ne peut pas être vide.";
    } else {
        // Insérer le message dans la table Messagerie
        $query = "INSERT INTO Messagerie (Message) VALUES ($1) RETURNING IdSession";
        $params = [$contenu];
        $result = pg_query_params($db, $query, $params);

        if (!$result) {
            $message = "Erreur lors de l'envoi du message: " . pg_last_error($db);
        } else {
            $idSession = pg_fetch_result($result, 0, 'idsession');

            // Insérer dans la table Envoyer
            $date = date('j n Y');
            list($jour, $mois, $annee) = explode(' ', $date);

            // Vérifier si la date existe dans LaDate
            $dateQuery = "SELECT COUNT(*) FROM LaDate WHERE Jour = $1 AND Mois = $2 AND Annee = $3";
            $dateResult = pg_query_params($db, $dateQuery, [$jour, $mois, $annee]);
            if (!$dateResult || pg_fetch_result($dateResult, 0, 0) == 0) {
                // Insérer la date dans LaDate si elle n'existe pas
                $insertDateQuery = "INSERT INTO LaDate (Jour, Mois, Annee) VALUES ($1, $2, $3)";
                pg_query_params($db, $insertDateQuery, [$jour, $mois, $annee]);
            }

            // Insérer dans la table Envoyer
            $query = "INSERT INTO Envoyer (IdSession, IdUtilisateur, Jour, Mois, Annee) VALUES ($1, $2, $3, $4, $5)";
            $params = [$idSession, $exp_id, $jour, $mois, $annee];
            $result = pg_query_params($db, $query, $params);
            if (!$result) {
                $message = "Erreur lors de l'envoi du message: " . pg_last_error($db);
            }

            // Insérer dans la table Recevoir
            $query = "INSERT INTO Recevoir (IdSession, IdUtilisateur, Jour, Mois, Annee) VALUES ($1, $2, $3, $4, $5)";
            $params = [$idSession, $dest_id, $jour, $mois, $annee];
            $result = pg_query_params($db, $query, $params);
            if (!$result) {
                $message = "Erreur lors de l'envoi du message: " . pg_last_error($db);
            }

            if (!$message) {
                $message = "Message envoyé avec succès à $prenom $nom!";
                // Redirection après succès
                header("refresh:3;url=contacts.php");
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Envoyer un message</title>
    <link rel="stylesheet" href="contacts.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f7f7f7;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #4CAF50;
        }
        textarea, button {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }
        textarea:focus, button:focus {
            border-color: #1c87c9;
            outline: none;
            box-shadow: 0 0 5px rgba(28, 135, 201, 0.5);
        }
        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 18px;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #45a049;
        }
        .success-message {
            text-align: center;
            color: green;
            font-size: 18px;
        }
        .error-message {
            text-align: center;
            color: red;
            font-size: 18px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Envoyer un message à <?php echo $prenom . ' ' . $nom; ?></h2>

        <?php if ($message): ?>
            <p class="<?php echo strpos($message, 'succès') !== false ? 'success-message' : 'error-message'; ?>">
                <?php echo $message; ?>
            </p>
        <?php endif; ?>

        <form method="POST" action="">
            <label for="contenu">Message :</label>
            <textarea id="contenu" name="contenu" rows="5" required></textarea>
            <button type="submit">Envoyer</button>
        </form>
        <form action="contacts.php" method="post">
            <button type="submit" class="back-button">Retour</button>
        </form>
    </div>
</body>
</html>

<?php
pg_close($db);
?>
