<?php
session_start();

// Inclure le fichier de connexion à la base de données
require 'db.php';

// Récupération des contacts (tous les utilisateurs)
$contactsQuery = "SELECT idutilisateur, nom, prenom FROM utilisateur";
$contactsResult = pg_query($db , $contactsQuery);

if (!$contactsResult) {
    die("Erreur lors de la récupération des contacts: " . pg_last_error($db ));
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contacts</title>
    <link rel="stylesheet" href="contacts.css">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        a.btn {
            display: inline-block;
            padding: 8px 16px;
            margin: 4px 0;
            color: #fff;
            background-color: #4CAF50;
            text-decoration: none;
            border-radius: 4px;
        }
        a.btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <header>
        <h1>Contacts</h1>
    </header>
    <main>
        <table>
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = pg_fetch_assoc($contactsResult)) : ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['nom']); ?></td>
                        <td><?php echo htmlspecialchars($row['prenom']); ?></td>
                        <td>
                            <a href="contacter.php?exp_id=305&dest_id=<?php echo urlencode($row['idutilisateur']); ?>&nom=<?php echo urlencode($row['nom']); ?>&prenom=<?php echo urlencode($row['prenom']); ?>" class="btn">Envoyer un message</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </main>
</body>
</html>

<?php
pg_close($db );
?>
