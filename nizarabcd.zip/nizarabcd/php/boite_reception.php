<?php
session_start();

// Inclure le fichier de connexion à la base de données
require 'db.php';

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    die("Vous devez être connecté pour voir cette page.");
}

// Récupérer l'ID de l'utilisateur connecté
$userId = $_SESSION['user_id'];

// Récupérer les messages reçus par l'utilisateur connecté
$query = "SELECT m.Message, m.IdSession, e.Jour, e.Mois, e.Annee, u.Nom, u.Prenom 
          FROM Messagerie m
          JOIN Recevoir r ON m.IdSession = r.IdSession
          JOIN Envoyer e ON m.IdSession = e.IdSession
          JOIN Utilisateur u ON e.IdUtilisateur = u.IdUtilisateur
          WHERE r.IdUtilisateur = $1
          ORDER BY r.Jour DESC, r.Mois DESC, r.Annee DESC";
$params = [$userId];
$result = pg_query_params($db, $query, $params);

if (!$result) {
    die("Erreur lors de la récupération des messages: " . pg_last_error($db));
}

$hasMessages = pg_num_rows($result) > 0;
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Boîte de Réception</title>
    <link rel="stylesheet" href="contacts.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f7f7f7;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #4CAF50;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .message-content {
            white-space: pre-wrap; /* Pour conserver les sauts de ligne */
        }
        .no-messages {
            text-align: center;
            color: #999;
            font-size: 18px;
            margin-top: 20px;
        }
        .no-messages span {
            color: #4CAF50;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Boîte de Réception</h2>
        <?php if ($hasMessages): ?>
            <table>
                <thead>
                    <tr>
                        <th>Nom de l'expéditeur</th>
                        <th>Prénom de l'expéditeur</th>
                        <th>Date</th>
                        <th>Message</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = pg_fetch_assoc($result)) : ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['nom']); ?></td>
                            <td><?php echo htmlspecialchars($row['prenom']); ?></td>
                            <td><?php echo htmlspecialchars($row['jour']) . '/' . htmlspecialchars($row['mois']) . '/' . htmlspecialchars($row['annee']); ?></td>
                            <td class="message-content"><?php echo htmlspecialchars($row['message']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="no-messages">Vous n'avez pas de nouveaux messages. Si vous avez besoin d'amis, utilisez <span>CovoiTECH</span> !</p>
        <?php endif; ?>
        <form action="contacts.php" method="post">
            <button type="submit" class="back-button">Retour</button>
        </form>
    </div>
</body>
</html>

<?php
pg_close($db);
?>
