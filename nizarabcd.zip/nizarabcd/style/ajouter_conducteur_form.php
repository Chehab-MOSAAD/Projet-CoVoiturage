<!DOCTYPE html>
<html lang="fr">
<head>
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- Title -->
    <title>Inscription Conducteur</title>
    
    <!-- Favicon -->
    <link rel="icon" href="images/favicon.png">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Nice Select CSS -->
    <link rel="stylesheet" href="css/nice-select.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!-- icofont CSS -->
    <link rel="stylesheet" href="css/icofont.css">
    <!-- Slicknav -->
    <link rel="stylesheet" href="css/slicknav.min.css">
    <!-- Owl Carousel CSS -->
    <link rel="stylesheet" href="css/owl-carousel.css">
    <!-- Datepicker CSS -->
    <link rel="stylesheet" href="css/datepicker.css">
    <!-- Animate CSS -->
    <link rel="stylesheet" href="css/animate.min.css">
    <!-- Magnific Popup CSS -->
    <link rel="stylesheet" href="css/magnific-popup.css">
    
    <!-- Medipro CSS -->
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/responsive.css">
    
    <style>
        .form-container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: #fff;
        }
        input, select, button {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }
        input:focus, select:focus, button:focus {
            border-color: #1c87c9;
            outline: none;
            box-shadow: 0 0 5px rgba(28, 135, 201, 0.5);
        }
        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 18px;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #45a049;
        }
        h3 {
            text-align: center;
            color: #1c87c9;
        }
        .back-button {
            background-color: #555;
        }
        .back-button:hover {
            background-color: #333;
        }
    </style>
</head>
<body>
    <!-- Preloader -->
    <div class="preloader">
        <div class="loader">
            <div class="loader-outter"></div>
            <div class="loader-inner"></div>
            <div class="indicator"> 
                <svg width="16px" height="12px">
                    <polyline id="back" points="1 6 4 6 6 11 10 1 12 6 15 6"></polyline>
                    <polyline id="front" points="1 6 4 6 6 11 10 1 12 6 15 6"></polyline>
                </svg>
            </div>
        </div>
    </div>
    <!-- End Preloader -->

    <!-- Header Area -->
    <header class="header">
        <!-- Header Inner -->
        <div class="header-inner">
            <div class="container">
                <div class="inner">
                    <div class="row">
                        <div class="col-lg-3 col-md-3 col-12">
                            <!-- Start Logo -->
                            <div class="logo">
                                <a href="/../CovoiTECH/chehab/Utilisateur_index.html"><img src="images/logo.png" alt="#"></a>
                            </div>
                            <!-- End Logo -->
                            <!-- Mobile Nav -->
                            <div class="mobile-nav"></div>
                            <!-- End Mobile Nav -->
                        </div>
                        <div class="col-lg-7 col-md-9 col-12">
                            <!-- Main Menu -->
                            <div class="main-menu">
                                <nav class="navigation">
                                    <ul class="nav menu">
                                        <li><a href="/../CovoiTECH/chehab/Utilisateur_index.html">Accueil</a></li>
                                        <li><a href="/../CovoiTECH/Miniar/recherche_voyage.php">Recherche</a></li>
                                        <li><a href="history.php">Profil</a></li>
                                        <li><a href="" class="typewrite" data-period="2000" data-type='[ "Bienvenue chez CovoiTECH", "Votre trajet, notre priorité", "Ensemble sur la route !" ]'></a></li>
                                    </ul>
                                </nav>
                            </div>
                            <!--/ End Main Menu -->
                        </div>
                        <div class="col-lg-2 col-12">
                            <div class="get-quote">
                                <a href="deconnexion.php" class="btn">Déconnexion</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/ End Header Inner -->
    </header>
    <!-- End Header Area -->

    <br/>
    <h3>Inscription Conducteur</h3>
    <br/>

    <div class="container form-container">
        <?php if (!empty($message)): ?>
            <p><?php echo $message; ?></p>
        <?php endif; ?>

        <form method="POST" action="ajouter_conducteur.php">
            <label for="numPermis">Numéro de Permis:</label>
            <input type="text" id="numPermis" name="numPermis" required><br>

            <label for="matricule">Matricule:</label>
            <input type="text" id="matricule" name="matricule" required><br>

            <label for="marque">Marque:</label>
            <input type="text" id="marque" name="marque" required><br>

            <label for="modele">Modèle:</label>
            <input type="text" id="modele" name="modele" required><br>

            <label for="type">Type:</label>
            <select id="type" name="type" required>
                <option value="SUV">SUV</option>
                <option value="Berline">Berline</option>
                <option value="Compacte">Compacte</option>
                <option value="Monospace">Monospace</option>
            </select><br>

            <label for="couleur">Couleur:</label>
            <select id="couleur" name="couleur" required>
                <option value="bleu">Bleu</option>
                <option value="violet">Violet</option>
                <option value="rose">Rose</option>
                <option value="rouge">Rouge</option>
                <option value="orange">Orange</option>
                <option value="jaune">Jaune</option>
                <option value="vert">Vert</option>
                <option value="noir">Noir</option>
                <option value="marron">Marron</option>
                <option value="gris">Gris</option>
                <option value="aluminium">Aluminium</option>
                <option value="argent">Argent</option>
                <option value="blanc">Blanc</option>
            </select><br>

            <label for="nbrPlace">Nombre de places:</label>
            <input type="number" id="nbrPlace" name="nbrPlace" required><br>

            <label for="carburant">Carburant:</label>
            <select id="carburant" name="carburant" required>
                <option value="essence">Essence</option>
                <option value="diesel">Diesel</option>
                <option value="éthanol">Éthanol</option>
                <option value="gaz">Gaz</option>
                <option value="électrique">Électrique</option>
                <option value="hybride">Hybride</option>
            </select><br>

            <button type="submit" name="ajouter_conducteur">Ajouter Conducteur</button>
        </form>
        <form action="success.php" method="post">
            <button type="submit" class="back-button">Retour</button>
        </form>
    </div>

    <!-- Footer Area -->
    <footer id="footer" class="footer">
        <div class="footer-top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 col-md-6 col-12">
                        <div class="single-footer">
                            <h2>À propos</h2>
                            <p>Notre site simule une plateforme intuitive où les utilisateurs peuvent proposer ou rechercher des trajets, gérer leurs réservations et interagir avec d’autres membres. L’accent a été mis sur la simplicité d’utilisation, la sécurité des données et la création d’une expérience utilisateur engageante.</p>
                            <p><br>Ce site web de covoiturage est le fruit d’un projet académique mené par un groupe d'étudiants de l’UPSSITECH, développé en PHP, HTML, CSS, Javascript et appuyé par une base de données robuste. Il sert principalement de démonstration des compétences techniques acquises durant notre année universitaire et n’est pas destiné à un usage commercial.</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="single-footer f-link">
                            <h2>Membres de l’équipe</h2>
                            <p>-> Chehab MOSAAD<br>-> Nizar SLAMA SEFI<br>-> Miniar JABRI<br>-> Lina AHNOUDJ<br>-> Linda BEDOUI</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--/ End Footer Area -->

    <!-- jquery Min JS -->
    <script src="js/jquery.min.js"></script>
    <!-- jquery Migrate JS -->
    <script src="js/jquery-migrate-3.0.0.js"></script>
    <!-- jquery Ui JS -->
    <script src="js/jquery-ui.min.js"></script>
    <!-- Easing JS -->
    <script src="js/easing.js"></script>
    <!-- Color JS -->
    <script src="js/colors.js"></script>
    <!-- Popper JS -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap Datepicker JS -->
    <script src="js/bootstrap-datepicker.js"></script>
    <!-- Jquery Nav JS -->
    <script src="js/jquery.nav.js"></script>
    <!-- Slicknav JS -->
    <script src="js/slicknav.min.js"></script>
    <!-- ScrollUp JS -->
    <script src="js/jquery.scrollUp.min.js"></script>
    <!-- Niceselect JS -->
    <script src="js/niceselect.js"></script>
    <!-- Tilt Jquery JS -->
    <script src="js/tilt.jquery.min.js"></script>
    <!-- Owl Carousel JS -->
    <script src="js/owl-carousel.js"></script>
    <!-- Counterup JS -->
    <script src="js/jquery.counterup.min.js"></script>
    <!-- Steller JS -->
    <script src="js/steller.js"></script>
    <!-- Wow JS -->
    <script src="js/wow.min.js"></script>
    <!-- Magnific Popup JS -->
    <script src="js/jquery.magnific-popup.min.js"></script>
    <!-- Counter Up CDN JS -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Main JS -->
    <script src="js/main.js"></script>
</body>
</html>
